import React, { useEffect, useRef, useState } from 'react';

export default function LoadingAnim({ onFinished }) {
  const [fade, setFade] = useState(false);
  const [videoOpacity, setVideoOpacity] = useState(0);
  const videoRef = useRef(null);

  useEffect(() => {
    // Smoothly fade in the video shortly after mounting
    const fadeInTimer = setTimeout(() => {
      setVideoOpacity(1);
    }, 150);

    // Robust fallback: after 6.5 seconds, transition to the app automatically
    const fallbackTimer = setTimeout(() => {
      handleVideoEnded();
    }, 6500);

    return () => {
      clearTimeout(fadeInTimer);
      clearTimeout(fallbackTimer);
    };
  }, []);

  const handleVideoEnded = () => {
    setFade(true);
    setTimeout(() => {
      if (onFinished) onFinished();
    }, 850); // Match CSS fade transition time
  };

  return (
    <div style={{
      ...styles.overlay,
      opacity: fade ? 0 : 1,
      transition: 'opacity 0.8s cubic-bezier(0.25, 1, 0.5, 1)',
      pointerEvents: fade ? 'none' : 'auto'
    }}>
      <video
        ref={videoRef}
        src="/entry_animation.mp4"
        autoPlay
        muted
        playsInline
        onEnded={handleVideoEnded}
        style={{
          ...styles.video,
          opacity: videoOpacity,
          transition: 'opacity 1s ease-in-out'
        }}
      />
    </div>
  );
}

const styles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100vw',
    height: '100vh',
    background: '#060B13', // Premium dark backdrop matching the luxury travel look
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 99999,
    overflow: 'hidden',
  },
  video: {
    width: '100%',
    height: '100%',
    objectFit: 'cover',
  }
};
