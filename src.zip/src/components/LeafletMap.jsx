import React, { useEffect, useRef } from 'react';

export default function LeafletMap({ driverLat, driverLng, hotelLat = 27.1685, hotelLng = 78.0422, hotelName = "ITC Mughal" }) {
  const mapContainerRef = useRef(null);
  const mapRef = useRef(null);
  const driverMarkerRef = useRef(null);
  const hotelMarkerRef = useRef(null);

  useEffect(() => {
    // Check if Leaflet L is loaded from CDN
    if (!window.L || !mapContainerRef.current) return;

    // Initializing the map
    if (!mapRef.current) {
      mapRef.current = window.L.map(mapContainerRef.current, {
        center: [hotelLat, hotelLng],
        zoom: 13,
        zoomControl: false,
        attributionControl: false
      });

      // Add a premium vector styled map tile layer
      window.L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        maxZoom: 19
      }).addTo(mapRef.current);

      // Create a beautiful custom hotel marker icon
      const hotelIcon = window.L.divIcon({
        className: 'custom-hotel-marker',
        html: `
          <div style="
            width: 36px;
            height: 36px;
            background-color: #D95D39;
            border: 2px solid #FAF7F2;
            border-radius: 50% 50% 50% 0;
            transform: rotate(-45deg);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 10px rgba(0,0,0,0.3);
          ">
            <div style="transform: rotate(45deg); font-size: 16px;">🏨</div>
          </div>
        `,
        iconSize: [36, 36],
        iconAnchor: [18, 36]
      });

      // Add hotel marker
      hotelMarkerRef.current = window.L.marker([hotelLat, hotelLng], { icon: hotelIcon })
        .addTo(mapRef.current)
        .bindPopup(`<b>${hotelName}</b><br/>Your Base Hotel`)
        .openPopup();
    }

    // Handle real-time driver/vehicle marker positioning
    if (driverLat && driverLng) {
      const dCoords = [driverLat, driverLng];

      if (!driverMarkerRef.current) {
        // Create custom vehicle marker icon (Peacock Green Car)
        const driverIcon = window.L.divIcon({
          className: 'custom-driver-marker',
          html: `
            <div style="
              width: 38px;
              height: 38px;
              background-color: #018E42;
              border: 2px solid #FAF7F2;
              border-radius: 50%;
              display: flex;
              align-items: center;
              justify-content: center;
              box-shadow: 0 4px 12px rgba(1, 142, 66, 0.4);
              animation: mapPulse 2s infinite;
            ">
              <div style="font-size: 18px;">🚗</div>
            </div>
          `,
          iconSize: [38, 38],
          iconAnchor: [19, 19]
        });

        driverMarkerRef.current = window.L.marker(dCoords, { icon: driverIcon })
          .addTo(mapRef.current)
          .bindPopup(`<b>Your Chauffeur</b><br/>En Route`);
      } else {
        // Smoothly transition coordinates
        driverMarkerRef.current.setLatLng(dCoords);
      }

      // Automatically adjust map frame to bound both the hotel and moving vehicle
      try {
        const bounds = window.L.latLngBounds([
          [hotelLat, hotelLng],
          [driverLat, driverLng]
        ]);
        mapRef.current.fitBounds(bounds, { padding: [50, 50] });
      } catch (err) {
        console.warn("Map bounds adjustment failed:", err);
      }
    }

    return () => {
      // Keep map persisted to avoid rebuild overhead unless unmounted
    };
  }, [driverLat, driverLng, hotelLat, hotelLng, hotelName]);

  // CSS for pulsing driver map pin
  useEffect(() => {
    const mapCss = `
      @keyframes mapPulse {
        0% { box-shadow: 0 0 0 0 rgba(1, 142, 66, 0.7); }
        70% { box-shadow: 0 0 0 12px rgba(1, 142, 66, 0); }
        100% { box-shadow: 0 0 0 0 rgba(1, 142, 66, 0); }
      }
    `;
    const style = document.createElement('style');
    style.appendChild(document.createTextNode(mapCss));
    document.head.appendChild(style);
    return () => {
      document.head.removeChild(style);
    };
  }, []);

  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', borderRadius: '18px', overflow: 'hidden' }}>
      <div ref={mapContainerRef} style={{ width: '100%', height: '100%', minHeight: '260px' }} />
      {/* Map Control Float overlay */}
      <div style={{
        position: 'absolute',
        bottom: '12px',
        left: '12px',
        backgroundColor: 'rgba(7, 30, 38, 0.85)',
        color: '#FAF7F2',
        padding: '6px 12px',
        borderRadius: '20px',
        fontSize: '0.68rem',
        fontWeight: '600',
        zIndex: 1000,
        pointerEvents: 'none',
        display: 'flex',
        alignItems: 'center',
        gap: '6px',
        backdropFilter: 'blur(4px)'
      }}>
        <span style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#018E42', display: 'inline-block' }} />
        GPS Live Satellites Connected
      </div>
    </div>
  );
}
