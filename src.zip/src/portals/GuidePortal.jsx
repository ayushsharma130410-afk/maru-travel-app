import React, { useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { listenToTour, listenToCities } from '../services/firebase';
import { Award, Phone, Calendar, MapPin, Navigation, User, Car, Info, ShieldAlert, Printer } from 'lucide-react';

export default function GuidePortal({ tourCode, onLogout }) {
  const { t, language } = useLanguage();
  const [tourData, setTourData] = useState(null);
  const [citiesData, setCitiesData] = useState([]);
  const [showPrintPreview, setShowPrintPreview] = useState(false);

  // Subscribe to tour changes
  useEffect(() => {
    const unsubscribe = listenToTour(tourCode, (data) => {
      if (data) setTourData(data);
    });
    return () => unsubscribe();
  }, [tourCode]);

  // Subscribe to cities info for local recommendations and emergency contacts
  useEffect(() => {
    const unsubscribe = listenToCities((data) => {
      if (data) setCitiesData(data);
    });
    return () => unsubscribe();
  }, []);

  if (!tourData) {
    return (
      <div style={styles.loaderWrap}>
        <div style={styles.spinner} />
        <p>{t('loadingSplash')}</p>
      </div>
    );
  }

  // Find active day
  const todayStr = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }).replace(/ /g, '-');
  const activeDayIndex = tourData.itinerary?.findIndex(d => d.dateStr === todayStr) ?? 0;
  const currentDayItinerary = tourData.itinerary?.[activeDayIndex === -1 ? 0 : activeDayIndex] || {};

  // Find details for current city
  const cityDetails = citiesData.find(c => c.name === currentDayItinerary.city) || null;

  if (showPrintPreview) {
    return (
      <div className="print-overlay" style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: '#f1f5f9', zIndex: 9999, overflowY: 'auto', display: 'flex', flexDirection: 'column' }}>
        <style>{`
          @media print {
            html, body, #root {
              width: auto !important;
              height: auto !important;
              overflow: visible !important;
              position: static !important;
              background: white !important;
              color: black !important;
            }
            .no-print {
              display: none !important;
            }
            @page {
              size: A4;
              margin: 0 !important;
            }
            #printable-area {
              margin: 0 !important;
              padding: 22mm !important;
              box-shadow: none !important;
              width: 100% !important;
              max-width: 100% !important;
              min-height: auto !important;
              display: block !important;
              position: static !important;
              border: none !important;
              background: white !important;
            }
            #printable-area table td,
            #printable-area table th {
              border-color: #000000 !important;
            }
            .print-page-border {
              display: none;
            }
            @media print {
              .print-page-border {
                display: block !important;
                position: fixed !important;
                top: 12mm !important;
                left: 12mm !important;
                right: 12mm !important;
                bottom: 12mm !important;
                border: 2px solid #000000 !important;
                z-index: 99999 !important;
                pointer-events: none !important;
                box-sizing: border-box !important;
              }
            }
          }
        `}</style>

        {/* Non-Printable Action Header */}
        <div className="no-print" style={{ height: '60px', backgroundColor: '#0B4F6C', color: '#FAF7F2', padding: '0 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', boxShadow: '0 2px 8px rgba(0,0,0,0.15)', flexShrink: 0 }}>
          <span style={{ fontWeight: '700', fontSize: '1rem' }}>PDF Tour Print Preview ({tourData.tourCode})</span>
          <div style={{ display: 'flex', gap: '12px' }}>
            <button onClick={() => window.print()} style={{ backgroundColor: '#10B981', color: 'white', border: 'none', padding: '8px 16px', borderRadius: '6px', fontWeight: '700', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.85rem' }}>
              <Printer size={16} /> Print Brief Itinerary
            </button>
            <button onClick={() => setShowPrintPreview(false)} style={{ backgroundColor: 'rgba(255,255,255,0.15)', color: 'white', border: '1px solid rgba(255,255,255,0.3)', padding: '8px 16px', borderRadius: '6px', fontWeight: '700', cursor: 'pointer', fontSize: '0.85rem' }}>
              ✕ Close Preview
            </button>
          </div>
        </div>

        {/* Printable A4 Itinerary Sheet */}
        <div id="printable-area" style={{ width: '794px', margin: '30px auto', padding: '40px', backgroundColor: '#ffffff', boxShadow: '0 4px 16px rgba(0,0,0,0.1)', boxSizing: 'border-box', color: '#000000', fontFamily: '"Segoe UI", Roboto, Helvetica, Arial, sans-serif', display: 'block' }}>
          <div className="print-page-border" />
          <table style={{ width: '100%', borderCollapse: 'collapse', border: 'none' }}>
            <thead>
              <tr>
                <td style={{ border: 'none', padding: '0 0 20px 0' }}>
                  {/* Header Brand */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '2.5px solid #d97706', paddingBottom: '12px' }}>
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
                      <img src="/maru_logo.png" alt="Maru Travel" style={{ height: '48px', marginBottom: '4px' }} />
                      <span style={{ fontSize: '0.62rem', letterSpacing: '2px', fontWeight: '800', color: '#d97706', textTransform: 'uppercase', margin: 0 }}>Making Travel an experience</span>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <h2 style={{ fontSize: '1.25rem', fontWeight: '800', color: '#d97706', letterSpacing: '1px', textTransform: 'uppercase', margin: 0 }}>“{tourData.tourName}”</h2>
                    </div>
                  </div>
                </td>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td style={{ border: 'none', padding: 0 }}>
                  {/* Brief Narrative Itinerary Layout */}
                  <div style={{ padding: '0 10px' }}>
                    <div style={{ textAlign: 'center', marginBottom: '24px' }}>
                      <div style={{ fontSize: '1rem', fontWeight: '800', textTransform: 'uppercase', color: '#0F172A', letterSpacing: '1.5px' }}>
                        {Array.from(new Set(tourData.itinerary?.map(d => d.city).filter(Boolean))).join(' - ')}
                      </div>
                      <div style={{ fontSize: '0.85rem', fontWeight: '700', color: '#475569', marginTop: '4px' }}>
                        {String(tourData.itinerary?.length ? tourData.itinerary.length - 1 : 0).padStart(2, '0')} Nights / {String(tourData.itinerary?.length || 0).padStart(2, '0')} Days
                      </div>
                    </div>

                    <div style={{ borderLeft: '3px solid #d97706', paddingLeft: '16px', margin: '20px 0' }}>
                      <span style={{ backgroundColor: '#0B4F6C', color: '#ffffff', padding: '4px 10px', fontWeight: '800', fontSize: '0.75rem', letterSpacing: '1px', textTransform: 'uppercase', borderRadius: '4px' }}>
                        Detailed Itinerary
                      </span>
                    </div>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px', margin: '20px 0' }}>
                      {tourData.itinerary?.map((day, idx) => (
                        <div key={idx} style={{ 
                          pageBreakInside: 'avoid', 
                          breakInside: 'avoid',
                          border: '1px solid #E2E8F0',
                          borderRadius: '8px',
                          padding: '16px',
                          backgroundColor: '#FCFBFA',
                          boxShadow: '0 1px 3px rgba(0,0,0,0.02)'
                        }}>
                          {/* Day Title Block */}
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1.5px solid #E2E8F0', paddingBottom: '10px', marginBottom: '12px' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                              <span style={{ backgroundColor: '#d97706', color: '#ffffff', padding: '3px 8px', borderRadius: '4px', fontSize: '0.8rem', fontWeight: '800' }}>
                                DAY {day.day}
                              </span>
                              <span style={{ fontSize: '0.9rem', fontWeight: '700', color: '#0F172A' }}>
                                {day.dateStr}
                              </span>
                            </div>
                            <span style={{ fontSize: '0.9rem', fontWeight: '800', color: '#0B4F6C', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                              {day.city}
                            </span>
                          </div>

                          {/* Day Activities */}
                          <div style={{ fontSize: '0.88rem', color: '#334155', lineHeight: '1.6', marginBottom: '14px', textAlign: 'justify' }}>
                            {day.activities || 'Leisure / Free time'} 
                          </div>

                          {/* Services Summary Box */}
                          <div style={{ 
                            display: 'grid', 
                            gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', 
                            gap: '12px', 
                            padding: '10px 14px', 
                            backgroundColor: '#F1F5F9', 
                            borderRadius: '6px',
                            fontSize: '0.8rem',
                            color: '#475569'
                          }}>
                            {day.hotelName && (
                              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                <span style={{ fontSize: '1rem' }}>🏨</span>
                                <div>
                                  <strong style={{ color: '#0F172A', display: 'block', fontSize: '0.72rem', textTransform: 'uppercase', opacity: 0.8 }}>Hotel Accommodation</strong>
                                  <span style={{ fontWeight: '600' }}>{day.hotelName}</span>
                                </div>
                              </div>
                            )}
                            {day.mealPlan && (
                              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                <span style={{ fontSize: '1rem' }}>🍽️</span>
                                <div>
                                  <strong style={{ color: '#0F172A', display: 'block', fontSize: '0.72rem', textTransform: 'uppercase', opacity: 0.8 }}>Meal Plan</strong>
                                  <span style={{ fontWeight: '600' }}>{day.mealPlan}</span>
                                </div>
                              </div>
                            )}
                            {(day.transport || day.flightNo || day.trainNo) && (
                              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                <span style={{ fontSize: '1rem' }}>🚗</span>
                                <div>
                                  <strong style={{ color: '#0F172A', display: 'block', fontSize: '0.72rem', textTransform: 'uppercase', opacity: 0.8 }}>Transport</strong>
                                  <span style={{ fontWeight: '600' }}>
                                    {day.flightNo ? `Flight: ${day.flightNo}` : day.trainNo ? `Train: ${day.trainNo}` : day.transport || 'By Surface'}
                                  </span>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>

                    <div style={{ textAlign: 'center', fontWeight: '800', fontSize: '0.95rem', margin: '40px 0 20px 0', letterSpacing: '2px', color: '#94A3B8' }}>
                      --- TOUR ENDS ---
                    </div>
                  </div>
                </td>
              </tr>
            </tbody>
            <tfoot>
              <tr>
                <td style={{ border: 'none', padding: '20px 0 0 0' }}>
                  {/* Structured Formal Footer Company Contact Address block */}
                  <div style={{ borderTop: '2px solid #d97706', paddingTop: '16px', display: 'flex', justifyContent: 'space-between', fontSize: '0.78rem', color: '#334155', fontFamily: 'sans-serif' }}>
                    <div>
                      <h4 style={{ margin: '0 0 4px 0', color: '#000000', fontWeight: '800', fontSize: '0.9rem' }}>Maru Travel</h4>
                      <div style={{ fontSize: '0.62rem', letterSpacing: '1px', fontWeight: '800', color: '#d97706', textTransform: 'uppercase', marginBottom: '8px' }}>
                        INDIA &nbsp;|&nbsp; SOUTH KOREA
                      </div>
                      <strong style={{ fontSize: '0.72rem', color: '#000000' }}>DELHI OFFICE:</strong>
                      <p style={{ margin: '2px 0 0 0', lineHeight: '1.4', fontSize: '0.75rem', color: '#475569' }}>
                        6A, First Floor, Uttam Nagar Main Rd<br/>
                        Near Metro Pillar No. 666<br/>
                        New Delhi - 110059
                      </p>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', textAlign: 'right', gap: '2px', fontSize: '0.75rem', color: '#475569' }}>
                      <span><strong>Mobile phone:</strong> +91-9811430044</span>
                      <span><strong>E Mail:</strong> ranjan@maru.travel</span>
                    </div>
                  </div>
                </td>
              </tr>
            </tfoot>
          </table>

        </div>
      </div>
    );
  }

  return (
    <div className="app-container">
      <header className="portal-header">
        <div className="portal-brand">
          <Award size={22} color="var(--primary)" />
          <span className="brand-text">{t('guidePortalTitle')}</span>
        </div>
        <div style={{ display: 'flex', gap: '8px' }}>
          <button onClick={() => setShowPrintPreview(true)} className="btn-secondary" style={{ padding: '6px 12px', fontSize: '0.8rem', backgroundColor: '#facc15', color: '#000', border: 'none' }}>
            <Printer size={16} /> Print
          </button>
          <button onClick={onLogout} className="btn-secondary" style={{ padding: '6px 12px', fontSize: '0.8rem' }}>
            {language === 'KO' ? '로그아웃' : 'Logout'}
          </button>
        </div>
      </header>

      <main className="portal-content-body" style={{ paddingBottom: '40px' }}>
        {/* Guest Overview Card */}
        <div className="client-hero-card">
          <span style={{ fontSize: '0.75rem', fontWeight: '800', opacity: 0.8 }}>TOUR ID: {tourCode}</span>
          <h2 style={{ fontFamily: 'var(--font-title)', fontSize: '1.4rem', fontWeight: '800', marginTop: '4px' }}>{tourData.tourName}</h2>
          <p style={{ fontSize: '0.85rem', marginTop: '6px', opacity: 0.9 }}>
            Client: {tourData.clientName} ({tourData.pax} Guests)
          </p>
        </div>

        {/* Crew / Driver details */}
        <h3 style={{ fontFamily: 'var(--font-title)', fontSize: '1.1rem', fontWeight: '800', margin: '20px 0 10px 0', color: 'var(--navy)' }}>
          Crew Coordination
        </h3>
        <div className="glass-panel" style={{ padding: '16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
          <div>
            <span style={{ fontSize: '0.68rem', fontWeight: '800', color: 'var(--primary)', textTransform: 'uppercase' }}>{t('driver')}</span>
            <h4 style={{ fontWeight: '700', fontSize: '1rem', color: 'var(--navy)', marginTop: '2px' }}>{tourData.driverName}</h4>
            <p style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>{tourData.vehicleNo} | {tourData.vehicleType}</p>
          </div>
          {tourData.driverMobile && (
            <a href={`tel:${tourData.driverMobile}`} className="btn-secondary" style={{ width: '40px', height: '40px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifycontent: 'center', padding: 0 }}>
              <Phone size={16} />
            </a>
          )}
        </div>

        {/* Today's Highlighted Plan */}
        <h3 style={{ fontFamily: 'var(--font-title)', fontSize: '1.1rem', fontWeight: '800', margin: '20px 0 10px 0', color: 'var(--navy)' }}>
          Today's Schedule ({currentDayItinerary.city})
        </h3>
        <div className="glass-panel" style={{ padding: '18px', borderLeft: '4px solid var(--primary)', marginBottom: '24px' }}>
          <span style={{ fontSize: '0.72rem', fontWeight: '800', color: 'var(--primary)' }}>TODAY'S HIGHLIGHT</span>
          <p style={{ fontSize: '0.88rem', fontWeight: '600', color: 'var(--text-primary)', marginTop: '4px' }}>{currentDayItinerary.activities}</p>

          {cityDetails && (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginTop: '16px', paddingTop: '16px', borderTop: '1px dashed var(--border)' }}>
              <div>
                <span style={{ fontSize: '0.68rem', fontWeight: '800', color: 'var(--primary)' }}>Famous Foods</span>
                <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', marginTop: '2px' }}>
                  {cityDetails.food?.map(f => `${f.emoji} ${f.name}`).join(', ')}
                </p>
              </div>
              <div>
                <span style={{ fontSize: '0.68rem', fontWeight: '800', color: 'var(--primary)' }}>Emergency Contacts</span>
                <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', marginTop: '2px' }}>{cityDetails.emergency}</p>
              </div>
            </div>
          )}
        </div>

        {/* Full Itinerary Overview */}
        <h3 style={{ fontFamily: 'var(--font-title)', fontSize: '1.1rem', fontWeight: '800', margin: '20px 0 10px 0', color: 'var(--navy)' }}>
          {t('guideItineraryOverview')}
        </h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {tourData.itinerary?.map((day, idx) => (
            <div key={idx} className="glass-panel" style={{ padding: '16px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                <h4 style={{ fontFamily: 'var(--font-title)', fontSize: '0.95rem', fontWeight: '800', color: 'var(--navy)' }}>
                  Day {day.day} ({day.dateStr}) - {day.city}
                </h4>
                <span style={{ fontSize: '0.7rem', fontWeight: '700', backgroundColor: 'var(--primary-light)', color: 'var(--primary-dark)', padding: '2px 8px', borderRadius: '10px' }}>
                  {day.mealPlan}
                </span>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', marginBottom: '8px' }}>
                {day.flightNo && <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>✈️ Flight: {day.flightNo}</span>}
                {day.trainNo && <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>🚆 Train: {day.trainNo}</span>}
                {day.localRestaurant && <span style={{ fontSize: '0.8rem', color: '#d97706', fontWeight: '600' }}>🍽️ Restaurant: {day.localRestaurant} ({day.restaurantMealType})</span>}
              </div>
              <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', lineHeight: '1.4' }}>{day.activities}</p>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}

const styles = {
  loaderWrap: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: '100vh',
    gap: '12px'
  },
  spinner: {
    width: '32px',
    height: '32px',
    border: '3px solid var(--border)',
    borderTopColor: 'var(--primary)',
    borderRadius: '50%',
    animation: 'spin 1s linear infinite'
  }
};
