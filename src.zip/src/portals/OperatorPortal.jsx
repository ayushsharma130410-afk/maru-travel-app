import React, { useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { 
  listenToCities, addCity, deleteCity,
  listenToHotels, addHotel, deleteHotel,
  listenToActivities, addActivity, deleteActivity,
  listenToGuides, addGuide, deleteGuide, getGuideBusyStatus,
  listenToDrivers, addDriver, deleteDriver,
  publishTour, listenToAllTours, updateTourResource, updateTour,
  listenToComplaints, signOutGoogle,
  listenToRestaurants, addRestaurant, deleteRestaurant
} from '../services/firebase';
import { 
  BarChart2, MapPin, Compass, Hotel, Award, Car, Clipboard, 
  Plus, Trash2, Calendar, Users, Phone, Shield, Star, Check, Globe, HelpCircle, Printer, UtensilsCrossed, Edit3
} from 'lucide-react';

const MEAL_PLAN_OPTIONS = [
  'No Meal',
  'Breakfast Only (CP)',
  'Breakfast & Lunch (AP Lunch)',
  'Breakfast & Dinner (MAP)',
  'Breakfast, Lunch & Dinner (AP)',
  'Lunch Only',
  'Dinner Only',
  'Lunch & Dinner'
];

export default function OperatorPortal({ onLogout }) {
  const { t, language } = useLanguage();
  const [activeTab, setActiveTab] = useState('dashboard'); // 'dashboard', 'cities', 'activities', 'hotels', 'guides', 'drivers', 'restaurants', 'tourBuilder'

  // Master Data
  const [cities, setCities] = useState([]);
  const [hotels, setHotels] = useState([]);
  const [activities, setActivities] = useState([]);
  const [guides, setGuides] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [tours, setTours] = useState([]);
  const [complaints, setComplaints] = useState([]);
  const [restaurants, setRestaurants] = useState([]);

  // Busy states for guides
  const [guideBusyStates, setGuideBusyStates] = useState({});

  // Filtering & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [cityFilter, setCityFilter] = useState('');

  // UI State
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [expandedTourCode, setExpandedTourCode] = useState(null);
  const [printTour, setPrintTour] = useState(null);
  const [editingTour, setEditingTour] = useState(null);
  const [printFormat, setPrintFormat] = useState('short');
  // Dashboard sub-views
  const [dashboardView, setDashboardView] = useState('daily'); // 'daily' | 'range'
  const [rangeFrom, setRangeFrom] = useState('');
  const [rangeTo, setRangeTo] = useState('');
  const [rangeCityFilter, setRangeCityFilter] = useState('');
  // Master itinerary selection
  const [selectedMasterItinerary, setSelectedMasterItinerary] = useState('');

  // New Entity Forms
  const [newCity, setNewCity] = useState({
    name: '', tagline: '', description: '', bestTime: '', language: '', currency: '', transport: '', emergency: '', imageUrl: '', mapUrl: ''
  });
  const [newActivity, setNewActivity] = useState({
    city: '', title: '', description: '', time: '2 hours', imageUrl: '', mapUrl: ''
  });
  const [newHotel, setNewHotel] = useState({
    city: '', name: '', stars: 5, phone: '', address: '', checkInOut: '2:00 PM → 12:00 PM', imageUrl: '', mapUrl: '',
    amenities: { Pool: true, Spa: true, Restaurant: true, Gym: true, WiFi: true, BarLounge: false, RoomService: false, Laundry: false, Parking: false, AirportShuttle: false }
  });
  const [newGuide, setNewGuide] = useState({ name: '', mobile: '' });
  const [newDriver, setNewDriver] = useState({ name: '', mobile: '', carNumber: '', vehicleType: 'Toyota Innova Crysta (SUV)' });
  const [newRestaurant, setNewRestaurant] = useState({ city: '', name: '', mealType: 'Lunch', cuisine: '', address: '', phone: '', mapUrl: '', imageUrl: '' });

  // Tour Builder State
  const [newTour, setNewTour] = useState({
    tourCode: '', tourName: '', clientName: '', pax: 2, startDate: '', endDate: '', guideName: '', driverName: ''
  });
  const [itineraryDays, setItineraryDays] = useState([]);

  // Subscriptions
  useEffect(() => {
    const unsubCities = listenToCities(setCities);
    const unsubHotels = listenToHotels(setHotels);
    const unsubActivities = listenToActivities(setActivities);
    const unsubGuides = listenToGuides(setGuides);
    const unsubDrivers = listenToDrivers(setDrivers);
    const unsubTours = listenToAllTours(setTours);
    const unsubComplaints = listenToComplaints(setComplaints);
    const unsubRestaurants = listenToRestaurants ? listenToRestaurants(setRestaurants) : () => {};

    return () => {
      unsubCities();
      unsubHotels();
      unsubActivities();
      unsubGuides();
      unsubDrivers();
      unsubTours();
      unsubComplaints();
      unsubRestaurants();
    };
  }, []);

  // Fetch guide busy statuses when guides or tours change
  useEffect(() => {
    guides.forEach((g) => {
      getGuideBusyStatus(g.name, (busyDates) => {
        setGuideBusyStates((prev) => ({ ...prev, [g.name]: busyDates }));
      });
    });
  }, [guides, tours]);

  // Handle Dynamic Day Generation for Tour Builder based on Start/End Dates
  useEffect(() => {
    if (!newTour.startDate || !newTour.endDate) return;
    const start = new Date(newTour.startDate);
    const end = new Date(newTour.endDate);
    const timeDiff = end.getTime() - start.getTime();
    if (timeDiff < 0) return;

    const daysCount = Math.floor(timeDiff / (1000 * 3600 * 24)) + 1;
    const newDays = [];

    // Pre-fill existing data if we are just expanding, otherwise default
    for (let i = 0; i < daysCount; i++) {
      const date = new Date(start);
      date.setDate(start.getDate() + i);
      const dateStr = date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }).replace(/ /g, '-');

      const existingDay = itineraryDays[i];
      newDays.push({
        day: i + 1,
        dateStr,
        city: existingDay?.city || (cities[0]?.name || ''),
        activities: existingDay?.activities || '',
        activitiesList: existingDay?.activitiesList || [{ time: '09:00 AM', title: '' }],
        hotelName: existingDay?.hotelName || '',
        hotelAddress: existingDay?.hotelAddress || '',
        hotelMapLink: existingDay?.hotelMapLink || '',
        mealPlan: existingDay?.mealPlan || 'Breakfast & Dinner (MAP)',
        transport: existingDay?.transport || 'By Surface',
        flightNo: existingDay?.flightNo || '',
        trainNo: existingDay?.trainNo || '',
        localRestaurant: existingDay?.localRestaurant || '',
        restaurantMealType: existingDay?.restaurantMealType || '',
        restaurantMapUrl: existingDay?.restaurantMapUrl || '',
        coverImage: existingDay?.coverImage || ''
      });
    }
    setItineraryDays(newDays);
  }, [newTour.startDate, newTour.endDate, cities]);

  // Paste image helper
  const handleImagePaste = (e, callback) => {
    const items = e.clipboardData?.items;
    if (!items) return;
    for (let i = 0; i < items.length; i++) {
      if (items[i].type.indexOf('image') !== -1) {
        const blob = items[i].getAsFile();
        const reader = new FileReader();
        reader.onload = (event) => {
          callback(event.target.result); // Base64 data URL
        };
        reader.readAsDataURL(blob);
        e.preventDefault();
        break;
      }
    }
  };

  // Generate unique Tour Code
  const generateTourCode = () => {
    const code = `MT-${new Date().getFullYear()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
    setNewTour(prev => ({ ...prev, tourCode: code }));
  };

  // Check if a guide is busy on specific dates
  const isGuideBusyOnDates = (guideName, startStr, endStr) => {
    const busyList = guideBusyStates[guideName] || [];
    if (!startStr || !endStr) return false;
    const start = new Date(startStr);
    const end = new Date(endStr);

    return busyList.some(b => {
      const bStart = new Date(b.startDate);
      const bEnd = new Date(b.endDate);
      return (start <= bEnd && end >= bStart);
    });
  };

  // Actions
  const handleAddCity = async (e) => {
    e.preventDefault();
    if (!newCity.name) return;
    await addCity(newCity);
    setNewCity({ name: '', tagline: '', description: '', bestTime: '', language: '', currency: '', transport: '', emergency: '', imageUrl: '', mapUrl: '' });
    setShowAddForm(false);
  };

  const handleAddActivity = async (e) => {
    e.preventDefault();
    if (!newActivity.title || !newActivity.city) return;
    await addActivity(newActivity);
    setNewActivity({ city: '', title: '', description: '', time: '2-3 hours', imageUrl: '', mapUrl: '' });
    setShowAddForm(false);
  };

  const handleAddHotel = async (e) => {
    e.preventDefault();
    if (!newHotel.name || !newHotel.city) return;
    const amenitiesArr = Object.entries(newHotel.amenities)
      .filter(([_, enabled]) => enabled)
      .map(([name]) => name);

    await addHotel({
      ...newHotel,
      amenities: amenitiesArr
    });
    setNewHotel({
      city: '', name: '', stars: 5, phone: '', address: '', checkInOut: '2:00 PM → 12:00 PM', imageUrl: '', mapUrl: '',
      amenities: { Pool: true, Spa: true, Restaurant: true, Gym: true, WiFi: true, BarLounge: false, RoomService: false, Laundry: false, Parking: false, AirportShuttle: false }
    });
    setShowAddForm(false);
  };

  const handleAddGuide = async (e) => {
    e.preventDefault();
    if (!newGuide.name || !newGuide.mobile) return;
    await addGuide(newGuide);
    setNewGuide({ name: '', mobile: '' });
    setShowAddForm(false);
  };

  const handleAddDriver = async (e) => {
    e.preventDefault();
    if (!newDriver.name || !newDriver.mobile) return;
    await addDriver(newDriver);
    setNewDriver({ name: '', mobile: '', carNumber: '', vehicleType: 'Toyota Innova Crysta (SUV)' });
    setShowAddForm(false);
  };

  const handleAddRestaurant = async (e) => {
    e.preventDefault();
    if (!newRestaurant.name || !newRestaurant.city) return;
    await addRestaurant(newRestaurant);
    setNewRestaurant({ city: '', name: '', mealType: 'Lunch', cuisine: '', address: '', phone: '', mapUrl: '', imageUrl: '' });
    setShowAddForm(false);
  };

  const handlePublishTour = async (e) => {
    e.preventDefault();
    if (!newTour.tourCode || !newTour.tourName || !newTour.clientName) {
      alert('Please fill out all tour details.');
      return;
    }

    const selectedGuideObj = guides.find(g => g.name === newTour.guideName);
    const selectedDriverObj = drivers.find(d => d.name === newTour.driverName);

    const tourData = {
      ...newTour,
      guideMobile: selectedGuideObj?.mobile || '',
      driverMobile: selectedDriverObj?.mobile || '',
      vehicleNo: selectedDriverObj?.carNumber || '',
      vehicleType: selectedDriverObj?.vehicleType || '',
      itinerary: itineraryDays
    };

    await publishTour(tourData);
    alert('Tour published successfully!');
    setNewTour({ tourCode: '', tourName: '', clientName: '', pax: 2, startDate: '', endDate: '', guideName: '', driverName: '' });
    setItineraryDays([]);
    setActiveTab('dashboard');
  };

  const handleSwapGuide = async (tourCode, guideName) => {
    const guideObj = guides.find(g => g.name === guideName);
    await updateTourResource(tourCode, 'guideName', guideName);
    if (guideObj) {
      await updateTourResource(tourCode, 'guideMobile', guideObj.mobile);
    }
  };

  const handleSwapDriver = async (tourCode, driverName) => {
    const driverObj = drivers.find(d => d.name === driverName);
    await updateTourResource(tourCode, 'driverName', driverName);
    if (driverObj) {
      await updateTourResource(tourCode, 'driverMobile', driverObj.mobile);
      await updateTourResource(tourCode, 'vehicleNo', driverObj.carNumber || '');
      await updateTourResource(tourCode, 'vehicleType', driverObj.vehicleType || '');
    }
  };

  // Filter Data arrays based on search/filters
  const filteredCities = cities.filter(c => c.name.toLowerCase().includes(searchQuery.toLowerCase()));
  const filteredActivities = activities.filter(a => {
    const matchesCity = cityFilter ? a.city === cityFilter : true;
    const matchesSearch = a.title.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCity && matchesSearch;
  });
  const filteredHotels = hotels.filter(h => {
    const matchesCity = cityFilter ? h.city === cityFilter : true;
    const matchesSearch = h.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCity && matchesSearch;
  });

  const activeTours = tours.filter(t => {
    if (!t.startDate || !t.endDate) return false;
    return selectedDate >= t.startDate && selectedDate <= t.endDate;
  });

  // Range-filtered tours for dashboard Part 2
  const rangeTours = tours.filter(t => {
    if (!t.startDate || !t.endDate) return false;
    const matchRange = (!rangeFrom || t.endDate >= rangeFrom) && (!rangeTo || t.startDate <= rangeTo);
    const matchCity = !rangeCityFilter || t.itinerary?.some(d => d.city === rangeCityFilter);
    return matchRange && matchCity;
  });

  // All unique cities across all tours for city filter dropdown
  const allTourCities = [...new Set(tours.flatMap(t => (t.itinerary || []).map(d => d.city)).filter(Boolean))];

  // Master Itinerary Templates
  const MASTER_ITINERARIES = [
    {
      id: 'golden-triangle-varanasi',
      name: 'Golden Triangle With Varanasi (08N/09D)',
      days: [
        { city: 'New Delhi', activities: 'Arrive at Indira Gandhi International Airport. Welcome to India! You will be met at the airport by representative. Transfer to hotel.\nOvernight stay at hotel.', transport: 'By Flight', mealPlan: 'No Meal', hotelName: '' },
        { city: 'New Delhi', activities: 'After breakfast proceed to full day Sightseeing you will visit Presidential Palace & Parliament Building (Exterior), Akshardham Temple, India Gate, Gandhi Smriti and Qutub Minar later back to hotel, Overnight Hotel.', transport: 'By Surface', mealPlan: 'Breakfast (CP)', hotelName: '' },
        { city: 'Varanasi', activities: "After breakfast transfer to Delhi Airport for board Flight. On arrival transfer to Hotel for Lunch and check in at hotel, In Evening Sightseeing 'Aarti Puja' with Ganges sunset - Rickshaw ride Back to hotel, Overnight at Hotel.", transport: 'By Flight', mealPlan: 'Breakfast (CP)', hotelName: '' },
        { city: 'Agra', activities: 'Early Sunrise at Ghat and back to hotel after breakfast transfer to Varanasi Airport for board Flight. Upon arrival Driver to Agra and upon arrival check in hotel and Overnight at Hotel.', transport: 'By Flight', mealPlan: 'Breakfast (CP)', hotelName: '' },
        { city: 'Agra', activities: 'After Breakfast - F/D sightseeing Taj Mahal & Agra Fort. Lunch & Dinner & Overnight at Hotel.', transport: 'By Surface', mealPlan: 'Breakfast & Dinner (MAP)', hotelName: '' },
        { city: 'Agra', activities: 'After Breakfast - sightseeing later day at leisure & Overnight at Hotel.', transport: 'By Surface', mealPlan: 'Breakfast (CP)', hotelName: '' },
        { city: 'Jaipur', activities: 'This morning, you will be drive Agra to Jaipur Enroute sightseeing Fatehpur Sikri on the way. Fatehpur Sikri built by Emperor Akbar in the 16th century holds exceptional testimony to Mughal civilization. You will visit the Jama Masjid, Tomb of Salim Chishti, Panch Mahal and Buland Darwaza. After the visit, you will be driven to Jaipur - the pink city. Overnight is in Jaipur.', transport: 'By Surface', mealPlan: 'Breakfast (CP)', hotelName: '' },
        { city: 'Jaipur', activities: 'The morning journey starts from Amer Fort. This magnificent fort was constructed in red sand-stone and marble by Raja Man Singh. You will visit Diwan-e-Aam, Diwan-e-Khas, Sheesh Mahal and Sukh Niwas. Then visit Maharaja City Palace, Jantar Mantar observatory. Drive past Hawa Mahal. Jaipur is famous for clothes, carpets, precious stones and jewellery. Overnight is in Jaipur.', transport: 'By Surface', mealPlan: 'Breakfast (CP)', hotelName: '' },
        { city: 'New Delhi', activities: 'After breakfast drive to Delhi, upon arrival transfer to the International airport to connect departure flight.', transport: 'By Surface', mealPlan: 'Breakfast (CP)', hotelName: '' },
      ]
    },
    {
      id: 'korea-golden-triangle-short',
      name: 'Korea Golden Triangle Short (07N/08D)',
      days: [
        { city: 'New Delhi', activities: 'ICN/DEL by KE497(1245-1820), Dinner and Overnight at Hotel.', transport: 'By Flight', mealPlan: 'Dinner Only', hotelName: '' },
        { city: 'Jaipur', activities: 'DEL-JAI SS(Amber Fort-Jeep, Hawa Mahal, City Palace, Jantar Mantar, Virla Mandir) On arrival lunch at Hotel and Dinner at Hotel, Overnight Hotel.', transport: 'By Surface', mealPlan: 'Breakfast, Lunch & Dinner (AP)', hotelName: '' },
        { city: 'Agra', activities: 'JAI-Abaneri SS(Chand Baori)-Fatehpur Sikri SS-AGR Lunch at local restaurant at Abhaneri and Dinner & Overnight Hotel.', transport: 'By Surface', mealPlan: 'Breakfast, Lunch & Dinner (AP)', hotelName: '' },
        { city: 'Agra', activities: 'SS(Taj Mahal, Agra Fort), Hena- Lunch and Dinner at Hotel and Overnight at Hotel.', transport: 'By Surface', mealPlan: 'Breakfast, Lunch & Dinner (AP)', hotelName: '' },
        { city: 'Khajuraho', activities: 'Train for Jhansi Vande Bharat (0745-1030)-Orcha SS-Khajuraho, Yoga Lunch at Amar Palace Orcha Dinner & Overnight at Hotel.', transport: 'By Train', mealPlan: 'Breakfast, Lunch & Dinner (AP)', hotelName: '' },
        { city: 'Varanasi', activities: 'SS(East & West Temples), Flight for VNS, Chai, Lassi, Rickshaw, Pooja Lunch & Dinner at Hotel.', transport: 'By Flight', mealPlan: 'Breakfast, Lunch & Dinner (AP)', hotelName: '' },
        { city: 'New Delhi', activities: 'Sunrise by boat on Ganga, SS(Sarnath, Museum), Flight for DEL. Lunch at Sarnath Varanasi and Dinner at Restaurant Delhi. Overnight at Hotel.', transport: 'By Flight', mealPlan: 'Breakfast, Lunch & Dinner (AP)', hotelName: '' },
        { city: 'New Delhi', activities: 'SS(Akshardham, India Gate, Gandhi Smriti, President Palace, Parliament House, Qutab Minar), Korean lunch at Gung. Later drop at airport DEL/ICN by KE498(1950-).', transport: 'By Surface', mealPlan: 'Breakfast & Lunch', hotelName: '' },
      ]
    }
  ];

  // Apply master itinerary template
  const applyMasterItinerary = (templateId) => {
    const template = MASTER_ITINERARIES.find(m => m.id === templateId);
    if (!template || !newTour.startDate) return;
    
    const start = new Date(newTour.startDate);
    const daysCount = template.days.length;
    const endDate = new Date(start);
    endDate.setDate(start.getDate() + daysCount - 1);
    const endDateStr = endDate.toISOString().split('T')[0];
    
    setNewTour(prev => ({ ...prev, endDate: endDateStr }));
    
    const newDays = template.days.map((td, i) => {
      const date = new Date(start);
      date.setDate(start.getDate() + i);
      const dateStr = date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }).replace(/ /g, '-');
      return {
        day: i + 1,
        dateStr,
        city: td.city,
        activities: td.activities,
        activitiesList: [{ time: '09:00 AM', title: '' }],
        hotelName: td.hotelName || '',
        hotelAddress: '',
        hotelMapLink: '',
        mealPlan: td.mealPlan || 'Breakfast & Dinner (MAP)',
        transport: td.transport || 'By Surface',
        flightNo: '',
        trainNo: '',
        localRestaurant: '',
        restaurantMealType: '',
        restaurantMapUrl: '',
        coverImage: ''
      };
    });
    setItineraryDays(newDays);
    setSelectedMasterItinerary(templateId);
  };

  // Helper to generate Sector codes DEL-JAI, etc.
  const getSectorCode = (day, idx, itinerary) => {
    if (idx === 0) {
      return `DEL`; 
    }
    const prevCity = itinerary[idx - 1].city;
    const currCity = day.city;
    if (prevCity !== currCity) {
      const getCode = (name) => {
        const n = name.trim().toUpperCase();
        if (n.includes('DELHI')) return 'DEL';
        if (n.includes('JAIPUR')) return 'JAI';
        if (n.includes('AGRA')) return 'AGR';
        if (n.includes('JODHPUR')) return 'JDH';
        if (n.includes('UDAIPUR')) return 'UDR';
        if (n.includes('JAISALMER')) return 'JSA';
        if (n.includes('KHAJURAHO')) return 'HJR';
        if (n.includes('VARANASI')) return 'VNS';
        if (n.includes('MUMBAI')) return 'BOM';
        if (n.includes('KOCHI')) return 'COK';
        return n.substring(0, 3);
      };
      return `${getCode(prevCity)}-${getCode(currCity)}`;
    }
    return currCity.trim().toUpperCase().substring(0, 3);
  };

  return (
    <div className="app-container">
      {/* Printable Tour Itinerary Sheet */}
      {printTour && (
        <div className="print-overlay" style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: '#f1f5f9', zIndex: 9999, overflowY: 'auto', display: 'flex', flexDirection: 'column' }}>
          <style>{`
            @media print {
              html, body, #root {
                width: auto !important;
                height: auto !important;
                overflow: visible !important;
                position: static !important;
                background: white !important;
                color: black !important;
              }
              .no-print {
                display: none !important;
              }
              .app-container {
                display: block !important;
                position: static !important;
                overflow: visible !important;
                width: auto !important;
                height: auto !important;
                min-height: auto !important;
              }
              .app-container > *:not(.print-overlay) {
                display: none !important;
              }
              .print-overlay {
                position: static !important;
                display: block !important;
                overflow: visible !important;
                width: 100% !important;
                height: auto !important;
                min-height: auto !important;
                background: white !important;
                padding: 0 !important;
                margin: 0 !important;
              }
              @page {
                size: A4;
                margin: 22mm !important;
              }
              #printable-area {
                margin: 0 !important;
                padding: 0 !important;
                box-shadow: none !important;
                width: 100% !important;
                max-width: 100% !important;
                min-height: auto !important;
                display: block !important;
                position: static !important;
                border: none !important;
                background: white !important;
              }
              #printable-area table td,
              #printable-area table th {
                border-color: #000000 !important;
              }
              /* Brief itinerary day cards get black borders in print */
              #printable-area .brief-day-card {
                border: 1px solid #000000 !important;
              }
              #printable-area .brief-services-box {
                border: 1px solid #000000 !important;
              }
              .print-page-border {
                display: none;
              }
              @media print {
                .print-page-border {
                  display: block !important;
                  position: fixed !important;
                  top: -10mm !important;
                  left: -10mm !important;
                  right: -10mm !important;
                  bottom: -10mm !important;
                  border: 2px solid #000000 !important;
                  z-index: 99999 !important;
                  pointer-events: none !important;
                  box-sizing: border-box !important;
                }
              }
            }
          `}</style>

          {/* Non-Printable Action Header */}
          <div className="no-print" style={{ height: '60px', backgroundColor: '#0B4F6C', color: '#FAF7F2', padding: '0 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', boxShadow: '0 2px 8px rgba(0,0,0,0.15)', flexShrink: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
              <span style={{ fontWeight: '700', fontSize: '1rem' }}>PDF Tour Print Preview ({printTour.tourCode})</span>
              
              {/* Format Dropdown Selector */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span style={{ fontSize: '0.8rem', opacity: 0.85 }}>Format:</span>
                <select 
                  value={printFormat} 
                  onChange={(e) => setPrintFormat(e.target.value)}
                  style={{ backgroundColor: 'rgba(255,255,255,0.15)', color: '#FAF7F2', border: '1px solid rgba(255,255,255,0.25)', padding: '6px 12px', borderRadius: '6px', fontSize: '0.82rem', outline: 'none', cursor: 'pointer', fontWeight: '600' }}
                >
                  <option value="short" style={{ color: 'black' }}>Short Itinerary (Grid / Confirmation Table)</option>
                  <option value="brief" style={{ color: 'black' }}>Brief Itinerary (Narrative / Date Schedule List)</option>
                </select>
              </div>
            </div>

            <div style={{ display: 'flex', gap: '12px' }}>
              <button onClick={() => window.print()} style={{ backgroundColor: '#10B981', color: 'white', border: 'none', padding: '8px 16px', borderRadius: '6px', fontWeight: '700', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.85rem' }}>
                <Printer size={16} /> Print Itinerary
              </button>
              <button onClick={() => setPrintTour(null)} style={{ backgroundColor: 'rgba(255,255,255,0.15)', color: 'white', border: '1px solid rgba(255,255,255,0.3)', padding: '8px 16px', borderRadius: '6px', fontWeight: '700', cursor: 'pointer', fontSize: '0.85rem' }}>
                ✕ Close Preview
              </button>
            </div>
          </div>

          {/* Printable A4 Itinerary Sheet */}
          <div id="printable-area" style={{ width: '794px', margin: '30px auto', padding: '40px', backgroundColor: '#ffffff', boxShadow: '0 4px 16px rgba(0,0,0,0.1)', boxSizing: 'border-box', color: '#000000', fontFamily: '"Segoe UI", Roboto, Helvetica, Arial, sans-serif', display: 'block' }}>
            <div className="print-page-border" />
            <table style={{ width: '100%', borderCollapse: 'collapse', border: 'none' }}>
              <thead>
                <tr>
                  <td style={{ border: 'none', padding: '0 0 20px 0' }}>
                    {/* Header Brand */}
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '2.5px solid #d97706', paddingBottom: '12px' }}>
                      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
                        <img src="/maru_logo.png" alt="Maru Travel" style={{ height: '48px', marginBottom: '4px' }} />
                        <span style={{ fontSize: '0.62rem', letterSpacing: '2px', fontWeight: '800', color: '#d97706', textTransform: 'uppercase', margin: 0 }}>Making Travel an experience</span>
                      </div>
                      <div style={{ textAlign: 'right' }}>
                        <h2 style={{ fontSize: '1.25rem', fontWeight: '800', color: '#d97706', letterSpacing: '1px', textTransform: 'uppercase', margin: 0 }}>“{printTour.tourName}”</h2>
                      </div>
                    </div>
                  </td>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td style={{ border: 'none', padding: 0 }}>
                    {printFormat === 'short' ? (
                      <>
                        {/* Metadata Fields (Beautiful structured grid matching professional PDF invoice layouts) */}
                        <div style={{ 
                          display: 'grid', 
                          gridTemplateColumns: '1fr 1fr', 
                          gap: '10px 24px', 
                          fontSize: '0.85rem', 
                          color: '#334155', 
                          marginBottom: '20px',
                          padding: '14px',
                          backgroundColor: '#F8FAFC',
                          borderRadius: '8px',
                          border: '1px solid #E2E8F0'
                        }}>
                          <div style={{ display: 'flex', borderBottom: '1px solid #F1F5F9', paddingBottom: '6px' }}>
                            <strong style={{ color: '#0F172A', width: '120px' }}>File Code:</strong>
                            <span>{printTour.tourCode}</span>
                          </div>
                          <div style={{ display: 'flex', borderBottom: '1px solid #F1F5F9', paddingBottom: '6px' }}>
                            <strong style={{ color: '#0F172A', width: '120px' }}>Group Name:</strong>
                            <span>{printTour.clientName} ({printTour.pax} Pax)</span>
                          </div>
                          <div style={{ display: 'flex', borderBottom: '1px solid #F1F5F9', paddingBottom: '6px' }}>
                            <strong style={{ color: '#0F172A', width: '120px' }}>Arrival Date:</strong>
                            <span>{printTour.startDate}</span>
                          </div>
                          <div style={{ display: 'flex', borderBottom: '1px solid #F1F5F9', paddingBottom: '6px' }}>
                            <strong style={{ color: '#0F172A', width: '120px' }}>Vehicle Type:</strong>
                            <span>{printTour.vehicleType || 'SUV (Chauffeur Driven)'} (Reg: {printTour.vehicleNo || 'TBA'})</span>
                          </div>
                          <div style={{ display: 'flex', borderBottom: '1px solid #F1F5F9', paddingBottom: '6px' }}>
                            <strong style={{ color: '#0F172A', width: '120px' }}>Transport:</strong>
                            <span>{Array.from(new Set(printTour.itinerary?.map(d => d.transport).filter(Boolean))).join(', ') || 'By Surface'}</span>
                          </div>
                          <div style={{ display: 'flex', borderBottom: '1px solid #F1F5F9', paddingBottom: '6px' }}>
                            <strong style={{ color: '#0F172A', width: '120px' }}>Guide / Escort:</strong>
                            <span>{printTour.guideName || 'TBA'} ({printTour.guideMobile || 'N/A'})</span>
                          </div>
                          <div style={{ display: 'flex', borderBottom: '1px solid #F1F5F9', paddingBottom: '6px', gridColumn: 'span 2' }}>
                            <strong style={{ color: '#0F172A', width: '120px' }}>Accommodation:</strong>
                            <span>{Array.from(new Set(printTour.itinerary?.map(d => d.hotelName).filter(Boolean))).join(' · ') || 'In Transit'}</span>
                          </div>
                        </div>

                        {/* Travel Program Table */}
                        <table style={{ width: '100%', borderCollapse: 'collapse', border: '1px solid #000000', marginTop: '10px' }}>
                          <thead>
                            <tr>
                              <th rowSpan="2" style={{ border: '1px solid #000000', padding: '8px', fontSize: '0.8rem', fontWeight: '800', backgroundColor: '#f8f9fa' }}>Date</th>
                              <th rowSpan="2" style={{ border: '1px solid #000000', padding: '8px', fontSize: '0.8rem', fontWeight: '800', backgroundColor: '#f8f9fa' }}>Sector</th>
                              <th rowSpan="2" style={{ border: '1px solid #000000', padding: '8px', fontSize: '0.8rem', fontWeight: '800', backgroundColor: '#f8f9fa' }}>Arrival FLT/<br/>Train</th>
                              <th rowSpan="2" style={{ border: '1px solid #000000', padding: '8px', fontSize: '0.8rem', fontWeight: '800', backgroundColor: '#f8f9fa' }}>City</th>
                              <th rowSpan="2" style={{ border: '1px solid #000000', padding: '8px', fontSize: '0.8rem', fontWeight: '800', backgroundColor: '#f8f9fa' }}>Hotels</th>
                              <th colSpan="4" style={{ border: '1px solid #000000', padding: '6px', fontSize: '0.8rem', fontWeight: '800', backgroundColor: '#f8f9fa', textAlign: 'center' }}>Remark / Confirmation Number</th>
                            </tr>
                            <tr>
                              <th style={{ border: '1px solid #000000', padding: '6px', fontSize: '0.72rem', fontWeight: '800', backgroundColor: '#f8f9fa', width: '90px' }}>Meal</th>
                              <th style={{ border: '1px solid #000000', padding: '6px', fontSize: '0.72rem', fontWeight: '800', backgroundColor: '#f8f9fa', width: '45px' }}>ADV-</th>
                              <th style={{ border: '1px solid #000000', padding: '6px', fontSize: '0.72rem', fontWeight: '800', backgroundColor: '#f8f9fa', width: '45px' }}>Vouch</th>
                              <th style={{ border: '1px solid #000000', padding: '6px', fontSize: '0.72rem', fontWeight: '800', backgroundColor: '#f8f9fa', width: '85px' }}>Final P-Con</th>
                            </tr>
                          </thead>
                          <tbody>
                            {printTour.itinerary?.map((day, idx) => (
                              <tr key={idx} style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                                <td style={{ border: '1px solid #000000', padding: '8px 6px', fontSize: '0.75rem', textAlign: 'center', fontWeight: '600' }}>
                                  {day.dateStr}
                                </td>
                                <td style={{ border: '1px solid #000000', padding: '8px 6px', fontSize: '0.75rem', textAlign: 'center', fontWeight: '700', color: '#1e3a8a' }}>
                                  {getSectorCode(day, idx, printTour.itinerary)}
                                </td>
                                <td style={{ border: '1px solid #000000', padding: '8px 6px', fontSize: '0.75rem', textAlign: 'center' }}>
                                  {day.transport === 'By Flight' ? (day.flightNo ? `By FLT - ${day.flightNo}` : 'By Flight') :
                                   day.transport === 'By Train' ? (day.trainNo ? `By TRN - ${day.trainNo}` : 'By Train') :
                                   day.transport || 'By Surface'}
                                </td>
                                <td style={{ border: '1px solid #000000', padding: '8px 6px', fontSize: '0.75rem', textAlign: 'center', fontWeight: '600' }}>
                                  {day.city}
                                </td>
                                <td style={{ border: '1px solid #000000', padding: '8px 6px', fontSize: '0.72rem', textAlign: 'center' }}>
                                  {day.hotelName || 'In Transit'}
                                </td>
                                <td style={{ border: '1px solid #000000', padding: '8px 6px', fontSize: '0.7rem', textAlign: 'center' }}>
                                  {day.mealPlan || 'Dinner'}
                                </td>
                                <td style={{ border: '1px solid #000000', padding: '8px 6px', fontSize: '0.75rem', textAlign: 'center' }}></td>
                                <td style={{ border: '1px solid #000000', padding: '8px 6px', fontSize: '0.75rem', textAlign: 'center' }}></td>
                                <td style={{ border: '1px solid #000000', padding: '8px 6px', fontSize: '0.75rem', textAlign: 'center' }}></td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </>
                    ) : (
                      <>
                        {/* Brief Narrative Itinerary Layout */}
                        <div style={{ padding: '0 10px' }}>
                          <div style={{ textAlign: 'center', marginBottom: '24px' }}>
                            <div style={{ fontSize: '1rem', fontWeight: '800', textTransform: 'uppercase', color: '#0F172A', letterSpacing: '1.5px' }}>
                              {Array.from(new Set(printTour.itinerary?.map(d => d.city).filter(Boolean))).join(' - ')}
                            </div>
                            <div style={{ fontSize: '0.85rem', fontWeight: '700', color: '#475569', marginTop: '4px' }}>
                              {String(printTour.itinerary?.length ? printTour.itinerary.length - 1 : 0).padStart(2, '0')} Nights / {String(printTour.itinerary?.length || 0).padStart(2, '0')} Days
                            </div>
                          </div>

                          <div style={{ borderLeft: '3px solid #d97706', paddingLeft: '16px', margin: '20px 0' }}>
                            <span style={{ backgroundColor: '#0B4F6C', color: '#ffffff', padding: '4px 10px', fontWeight: '800', fontSize: '0.75rem', letterSpacing: '1px', textTransform: 'uppercase', borderRadius: '4px' }}>
                              Detailed Itinerary
                            </span>
                          </div>

                          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px', margin: '20px 0' }}>
                            {printTour.itinerary?.map((day, idx) => (
                              <div key={idx} className="brief-day-card" style={{ 
                                pageBreakInside: 'avoid', 
                                breakInside: 'avoid',
                                border: '1px solid #E2E8F0',
                                borderRadius: '8px',
                                padding: '16px',
                                backgroundColor: '#FCFBFA',
                                boxShadow: '0 1px 3px rgba(0,0,0,0.02)'
                              }}>
                                {/* Day Title Block */}
                                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1.5px solid #E2E8F0', paddingBottom: '10px', marginBottom: '12px' }}>
                                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                    <span style={{ backgroundColor: '#d97706', color: '#ffffff', padding: '3px 8px', borderRadius: '4px', fontSize: '0.8rem', fontWeight: '800' }}>
                                      DAY {day.day}
                                    </span>
                                    <span style={{ fontSize: '0.9rem', fontWeight: '700', color: '#0F172A' }}>
                                      {day.dateStr}
                                    </span>
                                  </div>
                                  <span style={{ fontSize: '0.9rem', fontWeight: '800', color: '#0B4F6C', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                                    {day.city}
                                  </span>
                                </div>

                                {/* Day Activities */}
                                <div style={{ fontSize: '0.88rem', color: '#334155', lineHeight: '1.6', marginBottom: '14px', textAlign: 'justify' }}>
                                  {day.activities || 'Leisure / Free time'} 
                                </div>

                                {/* Services Summary Box */}
                                <div className="brief-services-box" style={{ 
                                  display: 'grid', 
                                  gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', 
                                  gap: '12px', 
                                  padding: '10px 14px', 
                                  backgroundColor: '#F1F5F9', 
                                  borderRadius: '6px',
                                  fontSize: '0.8rem',
                                  color: '#475569'
                                }}>
                                  {day.hotelName && (
                                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                      <span style={{ fontSize: '1rem' }}>🏨</span>
                                      <div>
                                        <strong style={{ color: '#0F172A', display: 'block', fontSize: '0.72rem', textTransform: 'uppercase', opacity: 0.8 }}>Hotel Accommodation</strong>
                                        <span style={{ fontWeight: '600' }}>{day.hotelName}</span>
                                      </div>
                                    </div>
                                  )}
                                  {day.mealPlan && (
                                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                      <span style={{ fontSize: '1rem' }}>🍽️</span>
                                      <div>
                                        <strong style={{ color: '#0F172A', display: 'block', fontSize: '0.72rem', textTransform: 'uppercase', opacity: 0.8 }}>Meal Plan</strong>
                                        <span style={{ fontWeight: '600' }}>{day.mealPlan}</span>
                                      </div>
                                    </div>
                                  )}
                                  {(day.transport || day.flightNo || day.trainNo) && (
                                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                      <span style={{ fontSize: '1rem' }}>🚗</span>
                                      <div>
                                        <strong style={{ color: '#0F172A', display: 'block', fontSize: '0.72rem', textTransform: 'uppercase', opacity: 0.8 }}>Transport</strong>
                                        <span style={{ fontWeight: '600' }}>
                                          {day.flightNo ? `Flight: ${day.flightNo}` : day.trainNo ? `Train: ${day.trainNo}` : day.transport || 'By Surface'}
                                        </span>
                                      </div>
                                    </div>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>

                          <div style={{ textAlign: 'center', fontWeight: '800', fontSize: '0.95rem', margin: '40px 0 20px 0', letterSpacing: '2px', color: '#94A3B8' }}>
                            --- TOUR ENDS ---
                          </div>
                        </div>
                      </>
                    )}
                  </td>
                </tr>
              </tbody>
              <tfoot>
                <tr>
                  <td style={{ border: 'none', padding: '20px 0 0 0' }}>
                    {/* Structured Formal Footer Company Contact Address block */}
                    <div style={{ borderTop: '2px solid #d97706', paddingTop: '16px', display: 'flex', justifyContent: 'space-between', fontSize: '0.78rem', color: '#334155', fontFamily: 'sans-serif' }}>
                      <div>
                        <h4 style={{ margin: '0 0 4px 0', color: '#000000', fontWeight: '800', fontSize: '0.9rem' }}>Maru Travel</h4>
                        <div style={{ fontSize: '0.62rem', letterSpacing: '1px', fontWeight: '800', color: '#d97706', textTransform: 'uppercase', marginBottom: '8px' }}>
                          INDIA &nbsp;|&nbsp; SOUTH KOREA
                        </div>
                        <strong style={{ fontSize: '0.72rem', color: '#000000' }}>DELHI OFFICE:</strong>
                        <p style={{ margin: '2px 0 0 0', lineHeight: '1.4', fontSize: '0.75rem', color: '#475569' }}>
                          6A, First Floor, Uttam Nagar Main Rd<br/>
                          Near Metro Pillar No. 666<br/>
                          New Delhi - 110059
                        </p>
                      </div>
                      <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', textAlign: 'right', gap: '2px', fontSize: '0.75rem', color: '#475569' }}>
                        <span><strong>Mobile phone:</strong> +91-9811430044</span>
                        <span><strong>E Mail:</strong> ranjan@maru.travel</span>
                      </div>
                    </div>
                  </td>
                </tr>
              </tfoot>
            </table>

          </div>
        </div>
      )}
      {/* Live Tour Itinerary Editor */}
      {editingTour && (
        <div className="print-overlay" style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: '#f1f5f9', zIndex: 9999, overflowY: 'auto', display: 'flex', flexDirection: 'column' }}>
          {/* Editor Header Bar */}
          <div style={{ height: '60px', backgroundColor: '#0B4F6C', color: '#FAF7F2', padding: '0 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', boxShadow: '0 2px 8px rgba(0,0,0,0.15)', flexShrink: 0 }}>
            <span style={{ fontWeight: '700', fontSize: '1rem' }}>✏️ Live Edit Tour Details & Itinerary ({editingTour.tourCode})</span>
            <div style={{ display: 'flex', gap: '12px' }}>
              <button 
                onClick={async () => {
                  await updateTour(editingTour.tourCode, editingTour);
                  setEditingTour(null);
                  alert('Tour updated successfully live!');
                }} 
                style={{ backgroundColor: '#10B981', color: 'white', border: 'none', padding: '8px 16px', borderRadius: '6px', fontWeight: '700', cursor: 'pointer', fontSize: '0.85rem' }}
              >
                💾 Save Live Changes
              </button>
              <button onClick={() => setEditingTour(null)} style={{ backgroundColor: 'rgba(255,255,255,0.15)', color: 'white', border: '1px solid rgba(255,255,255,0.3)', padding: '8px 16px', borderRadius: '6px', fontWeight: '700', cursor: 'pointer', fontSize: '0.85rem' }}>
                ✕ Cancel
              </button>
            </div>
          </div>

          {/* Form Container */}
          <div style={{ maxWidth: '800px', width: '100%', margin: '30px auto', padding: '30px', backgroundColor: '#ffffff', borderRadius: '12px', boxShadow: '0 4px 16px rgba(0,0,0,0.1)', boxSizing: 'border-box' }}>
            <h3 style={{ fontFamily: 'var(--font-title)', fontWeight: '800', color: 'var(--navy)', marginBottom: '20px' }}>General Information</h3>
            <div className="mgmt-form" style={{ gap: '20px' }}>
              <div className="mgmt-form-row">
                <div>
                  <label className="login-label" style={{ color: 'var(--text-primary)' }}>Tour Code (Cannot be changed)</label>
                  <input className="mgmt-input" required readOnly value={editingTour.tourCode} style={{ backgroundColor: '#f1f5f9', cursor: 'not-allowed' }} />
                </div>
                <div>
                  <label className="login-label" style={{ color: 'var(--text-primary)' }}>Tour Title / Name</label>
                  <input className="mgmt-input" required value={editingTour.tourName} onChange={(e) => setEditingTour({ ...editingTour, tourName: e.target.value })} />
                </div>
              </div>

              <div className="mgmt-form-row">
                <div>
                  <label className="login-label" style={{ color: 'var(--text-primary)' }}>Client Name</label>
                  <input className="mgmt-input" required value={editingTour.clientName} onChange={(e) => setEditingTour({ ...editingTour, clientName: e.target.value })} />
                </div>
                <div>
                  <label className="login-label" style={{ color: 'var(--text-primary)' }}>No. of Passengers (Pax)</label>
                  <input type="number" className="mgmt-input" required value={editingTour.pax} onChange={(e) => setEditingTour({ ...editingTour, pax: parseInt(e.target.value) })} />
                </div>
              </div>

              <div className="mgmt-form-row">
                <div>
                  <label className="login-label" style={{ color: 'var(--text-primary)' }}>Start Date</label>
                  <input type="date" className="mgmt-input" required value={editingTour.startDate} onChange={(e) => setEditingTour({ ...editingTour, startDate: e.target.value })} />
                </div>
                <div>
                  <label className="login-label" style={{ color: 'var(--text-primary)' }}>End Date</label>
                  <input type="date" className="mgmt-input" required value={editingTour.endDate} onChange={(e) => setEditingTour({ ...editingTour, endDate: e.target.value })} />
                </div>
              </div>

              <div className="mgmt-form-row">
                <div>
                  <label className="login-label" style={{ color: 'var(--text-primary)' }}>Assigned Guide</label>
                  <select className="mgmt-select" required value={editingTour.guideName} onChange={(e) => {
                    const guideObj = guides.find(g => g.name === e.target.value);
                    setEditingTour({
                      ...editingTour,
                      guideName: e.target.value,
                      guideMobile: guideObj?.mobile || ''
                    });
                  }}>
                    <option value="">Select Guide</option>
                    {guides.map(g => (
                      <option key={g.id} value={g.name}>{g.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="login-label" style={{ color: 'var(--text-primary)' }}>Assigned Driver & Car</label>
                  <select className="mgmt-select" required value={editingTour.driverName} onChange={(e) => {
                    const driverObj = drivers.find(d => d.name === e.target.value);
                    setEditingTour({
                      ...editingTour,
                      driverName: e.target.value,
                      driverMobile: driverObj?.mobile || '',
                      vehicleNo: driverObj?.carNumber || '',
                      vehicleType: driverObj?.vehicleType || ''
                    });
                  }}>
                    <option value="">Select Driver</option>
                    {drivers.map(d => (
                      <option key={d.id} value={d.name}>{d.name} ({d.vehicleType})</option>
                    ))}
                  </select>
                </div>
              </div>

              <h4 style={{ fontFamily: 'var(--font-title)', fontWeight: '800', marginTop: '24px', color: 'var(--navy)' }}>Itinerary Plan</h4>
              {editingTour.itinerary?.map((day, idx) => {
                const hotelsInCity = hotels.filter(h => h.city === day.city);
                const activitiesInCity = activities.filter(a => a.city === day.city);

                return (
                  <div key={idx} className="itin-day-card" style={{ border: '1px solid var(--border)', padding: '16px', borderRadius: '8px', marginBottom: '16px', backgroundColor: '#f8fafc' }}>
                    <div style={{ fontWeight: '700', marginBottom: '10px' }}>Day {day.day} ({day.dateStr})</div>
                    
                    <div className="mgmt-form-row" style={{ marginBottom: '12px' }}>
                      <div>
                        <label className="login-label" style={{ color: 'var(--text-primary)', fontSize: '0.78rem' }}>City Location</label>
                        <select className="mgmt-select" value={day.city} onChange={(e) => {
                          const updated = [...editingTour.itinerary];
                          updated[idx].city = e.target.value;
                          updated[idx].hotelName = '';
                          const cityObj = cities.find(c => c.name === e.target.value);
                          updated[idx].coverImage = cityObj?.imageUrl || '';
                          setEditingTour({ ...editingTour, itinerary: updated });
                        }}>
                          {cities.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                        </select>
                      </div>

                      <div>
                        <label className="login-label" style={{ color: 'var(--text-primary)', fontSize: '0.78rem' }}>Overnight Hotel</label>
                        <select className="mgmt-select" value={day.hotelName} onChange={(e) => {
                          const updated = [...editingTour.itinerary];
                          updated[idx].hotelName = e.target.value;
                          const h = hotels.find(hotel => hotel.name === e.target.value);
                          updated[idx].hotelAddress = h?.address || '';
                          updated[idx].hotelMapLink = h?.mapUrl || '';
                          setEditingTour({ ...editingTour, itinerary: updated });
                        }}>
                          <option value="">No Hotel / In-Transit</option>
                          {hotelsInCity.map(h => <option key={h.id} value={h.name}>{h.name}</option>)}
                        </select>
                      </div>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: '12px', marginBottom: '12px' }}>
                      <div>
                        <label className="login-label" style={{ color: 'var(--text-primary)', fontSize: '0.78rem' }}>Activities Checklist (Select for Client View)</label>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginTop: '6px' }}>
                          {activitiesInCity.map(act => {
                            const isSelected = day.activitiesList?.some(item => item.title === act.title);
                            return (
                              <button
                                key={act.id}
                                type="button"
                                onClick={() => {
                                  const updated = [...editingTour.itinerary];
                                  const list = day.activitiesList ? [...day.activitiesList] : [];
                                  const matchIndex = list.findIndex(item => item.title === act.title);
                                  if (matchIndex > -1) {
                                    list.splice(matchIndex, 1);
                                  } else {
                                    list.push({ time: '09:00 AM', title: act.title });
                                  }
                                  updated[idx].activitiesList = list;
                                  setEditingTour({ ...editingTour, itinerary: updated });
                                }}
                                style={{
                                  fontSize: '0.72rem',
                                  padding: '4px 10px',
                                  borderRadius: '6px',
                                  border: '1px solid var(--border)',
                                  backgroundColor: isSelected ? 'var(--primary-light)' : 'white',
                                  color: isSelected ? 'var(--primary-dark)' : 'var(--text-secondary)',
                                  cursor: 'pointer'
                                }}
                              >
                                {isSelected ? '✓ ' : ''}{act.title}
                              </button>
                            );
                          })}
                        </div>

                        {/* Time inputs for selected activities */}
                        {day.activitiesList?.length > 0 && (
                          <div style={{ marginTop: '12px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                            <label className="login-label" style={{ color: 'var(--text-primary)', fontSize: '0.78rem', fontWeight: '700' }}>⏰ Set Activity Times</label>
                            {day.activitiesList.map((act, actIdx) => (
                              <div key={actIdx} style={{ display: 'flex', alignItems: 'center', gap: '10px', backgroundColor: '#f8fafc', padding: '8px 12px', borderRadius: '8px', border: '1px solid var(--border-light)' }}>
                                <input
                                  type="time"
                                  className="mgmt-input"
                                  style={{ width: '120px', padding: '6px 8px', fontSize: '0.82rem' }}
                                  value={(() => {
                                    const t = act.time || '09:00 AM';
                                    const match = t.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
                                    if (match) {
                                      let h = parseInt(match[1]);
                                      const m = match[2];
                                      const ampm = match[3].toUpperCase();
                                      if (ampm === 'PM' && h !== 12) h += 12;
                                      if (ampm === 'AM' && h === 12) h = 0;
                                      return `${String(h).padStart(2, '0')}:${m}`;
                                    }
                                    return '09:00';
                                  })()}
                                  onChange={(e) => {
                                    const updated = [...editingTour.itinerary];
                                    const val = e.target.value;
                                    const [hStr, mStr] = val.split(':');
                                    let h = parseInt(hStr);
                                    const ampm = h >= 12 ? 'PM' : 'AM';
                                    if (h > 12) h -= 12;
                                    if (h === 0) h = 12;
                                    const formatted = `${String(h).padStart(2, '0')}:${mStr} ${ampm}`;
                                    updated[idx].activitiesList[actIdx].time = formatted;
                                    setEditingTour({ ...editingTour, itinerary: updated });
                                  }}
                                />
                                <span style={{ flex: 1, fontSize: '0.82rem', fontWeight: '600' }}>{act.title}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="mgmt-form-row">
                      <div>
                        <label className="login-label" style={{ color: 'var(--text-primary)', fontSize: '0.78rem' }}>Transport Mode</label>
                        <select className="mgmt-select" value={day.transport} onChange={(e) => {
                          const updated = [...editingTour.itinerary];
                          updated[idx].transport = e.target.value;
                          if (e.target.value !== 'By Flight') updated[idx].flightNo = '';
                          if (e.target.value !== 'By Train') updated[idx].trainNo = '';
                          setEditingTour({ ...editingTour, itinerary: updated });
                        }}>
                          <option value="By Surface">By Surface (Chauffeur Car)</option>
                          <option value="By Train">By Train</option>
                          <option value="By Flight">By Flight</option>
                        </select>
                      </div>
                      <div>
                        <label className="login-label" style={{ color: 'var(--text-primary)', fontSize: '0.78rem' }}>Meal Plan</label>
                        <select className="mgmt-select" value={day.mealPlan} onChange={(e) => {
                          const updated = [...editingTour.itinerary];
                          updated[idx].mealPlan = e.target.value;
                          setEditingTour({ ...editingTour, itinerary: updated });
                        }}>
                          {MEAL_PLAN_OPTIONS.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                        </select>
                      </div>
                    </div>

                    {day.transport === 'By Flight' && (
                      <div style={{ marginTop: '12px' }}>
                        <label className="login-label" style={{ color: 'var(--text-primary)', fontSize: '0.78rem' }}>✈️ Flight Number</label>
                        <input className="mgmt-input" placeholder="e.g. AI 302" value={day.flightNo || ''} onChange={(e) => {
                          const updated = [...editingTour.itinerary];
                          updated[idx].flightNo = e.target.value;
                          setEditingTour({ ...editingTour, itinerary: updated });
                        }} />
                      </div>
                    )}
                    {day.transport === 'By Train' && (
                      <div style={{ marginTop: '12px' }}>
                        <label className="login-label" style={{ color: 'var(--text-primary)', fontSize: '0.78rem' }}>🚆 Train Number</label>
                        <input className="mgmt-input" placeholder="e.g. 12952 Rajdhani" value={day.trainNo || ''} onChange={(e) => {
                          const updated = [...editingTour.itinerary];
                          updated[idx].trainNo = e.target.value;
                          setEditingTour({ ...editingTour, itinerary: updated });
                        }} />
                      </div>
                    )}

                    {/* Local Restaurant Selection */}
                    <div className="mgmt-form-row" style={{ marginTop: '12px' }}>
                      <div>
                        <label className="login-label" style={{ color: 'var(--text-primary)', fontSize: '0.78rem' }}>🍽️ Local Restaurant</label>
                        <select className="mgmt-select" value={day.localRestaurant || ''} onChange={(e) => {
                          const updated = [...editingTour.itinerary];
                          const rest = restaurants.find(r => r.name === e.target.value);
                          updated[idx].localRestaurant = e.target.value;
                          updated[idx].restaurantMealType = rest?.mealType || '';
                          updated[idx].restaurantMapUrl = rest?.mapUrl || '';
                          setEditingTour({ ...editingTour, itinerary: updated });
                        }}>
                          <option value="">No Restaurant Assigned</option>
                          {restaurants.filter(r => r.city === day.city).map(r => (
                            <option key={r.id} value={r.name}>{r.name} ({r.mealType} - {r.cuisine})</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div style={{ marginTop: '12px' }}>
                      <label className="login-label" style={{ color: 'var(--text-primary)', fontSize: '0.78rem' }}>Day Notes / Description (Brief Itinerary Text)</label>
                      <textarea className="mgmt-textarea" rows={2} value={day.activities} onChange={(e) => {
                        const updated = [...editingTour.itinerary];
                        updated[idx].activities = e.target.value;
                        setEditingTour({ ...editingTour, itinerary: updated });
                      }} />
                    </div>
                  </div>
                );
              })}
              
              <button 
                type="button" 
                onClick={async () => {
                  await updateTour(editingTour.tourCode, editingTour);
                  setEditingTour(null);
                  alert('Tour updated successfully live!');
                }} 
                className="btn-primary" 
                style={{ width: '100%', padding: '14px', borderRadius: '8px', fontWeight: '700', fontSize: '1rem', marginTop: '20px' }}
              >
                💾 Save Live Changes & Update Sync
              </button>
            </div>
          </div>
        </div>
      )}

      <header className="portal-header">
        <div className="portal-brand">
          <img src="/maru_logo.png" alt="Maru Travel" style={{ height: '32px' }} />
          <span className="brand-text">MARU TRAVEL OPERATOR</span>
        </div>
        <button onClick={async () => { await signOutGoogle(); onLogout(); }} className="btn-secondary" style={{ padding: '6px 14px', fontSize: '0.82rem' }}>
          {language === 'KO' ? '로그아웃' : 'Logout'}
        </button>
      </header>

      <div className="portal-content-body">
        {/* Navigation Tabs */}
        <div className="mgmt-tabs">
          <button className={`mgmt-tab ${activeTab === 'dashboard' ? 'mgmt-tab-active' : ''}`} onClick={() => { setActiveTab('dashboard'); setShowAddForm(false); setSearchQuery(''); }}>
            <BarChart2 size={16} /> {t('mgmtDashboard')}
          </button>
          <button className={`mgmt-tab ${activeTab === 'cities' ? 'mgmt-tab-active' : ''}`} onClick={() => { setActiveTab('cities'); setShowAddForm(false); setSearchQuery(''); }}>
            <MapPin size={16} /> {t('mgmtCities')}
          </button>
          <button className={`mgmt-tab ${activeTab === 'activities' ? 'mgmt-tab-active' : ''}`} onClick={() => { setActiveTab('activities'); setShowAddForm(false); setSearchQuery(''); }}>
            <Compass size={16} /> {t('mgmtActivities')}
          </button>
          <button className={`mgmt-tab ${activeTab === 'hotels' ? 'mgmt-tab-active' : ''}`} onClick={() => { setActiveTab('hotels'); setShowAddForm(false); setSearchQuery(''); }}>
            <Hotel size={16} /> {t('mgmtHotels')}
          </button>
          <button className={`mgmt-tab ${activeTab === 'guides' ? 'mgmt-tab-active' : ''}`} onClick={() => { setActiveTab('guides'); setShowAddForm(false); setSearchQuery(''); }}>
            <Award size={16} /> {t('mgmtGuides')}
          </button>
          <button className={`mgmt-tab ${activeTab === 'drivers' ? 'mgmt-tab-active' : ''}`} onClick={() => { setActiveTab('drivers'); setShowAddForm(false); setSearchQuery(''); }}>
            <Car size={16} /> {t('mgmtDrivers')}
          </button>
          <button className={`mgmt-tab ${activeTab === 'restaurants' ? 'mgmt-tab-active' : ''}`} onClick={() => { setActiveTab('restaurants'); setShowAddForm(false); setSearchQuery(''); }}>
            <UtensilsCrossed size={16} /> Restaurants
          </button>
          <button className={`mgmt-tab ${activeTab === 'tourBuilder' ? 'mgmt-tab-active' : ''}`} onClick={() => { setActiveTab('tourBuilder'); setShowAddForm(false); }}>
            <Clipboard size={16} /> {t('mgmtTourBuilder')}
          </button>
        </div>

        {/* TAB 1: DASHBOARD */}
        {activeTab === 'dashboard' && (
          <div className="mgmt-content">
            <div className="mgmt-stat-grid">
              <div className="mgmt-stat-card">
                <div className="mgmt-stat-icon-wrap"><Compass /></div>
                <div>
                  <h4 style={{ fontSize: '1.25rem', fontWeight: '800' }}>{cities.length}</h4>
                  <p style={{ fontSize: '0.72rem', color: 'var(--text-secondary)' }}>{t('totalCities')}</p>
                </div>
              </div>
              <div className="mgmt-stat-card">
                <div className="mgmt-stat-icon-wrap"><Hotel /></div>
                <div>
                  <h4 style={{ fontSize: '1.25rem', fontWeight: '800' }}>{hotels.length}</h4>
                  <p style={{ fontSize: '0.72rem', color: 'var(--text-secondary)' }}>{t('totalHotels')}</p>
                </div>
              </div>
              <div className="mgmt-stat-card">
                <div className="mgmt-stat-icon-wrap"><Award /></div>
                <div>
                  <h4 style={{ fontSize: '1.25rem', fontWeight: '800' }}>{guides.length}</h4>
                  <p style={{ fontSize: '0.72rem', color: 'var(--text-secondary)' }}>{t('totalGuides')}</p>
                </div>
              </div>
              <div className="mgmt-stat-card">
                <div className="mgmt-stat-icon-wrap"><Clipboard /></div>
                <div>
                  <h4 style={{ fontSize: '1.25rem', fontWeight: '800' }}>{tours.length}</h4>
                  <p style={{ fontSize: '0.72rem', color: 'var(--text-secondary)' }}>Total Tours</p>
                </div>
              </div>
            </div>

            {/* Dashboard Sub-Tabs */}
            <div style={{ display: 'flex', gap: '0', marginBottom: '20px', borderBottom: '2px solid var(--border)' }}>
              <button
                onClick={() => setDashboardView('daily')}
                style={{
                  padding: '10px 24px', fontWeight: '700', fontSize: '0.88rem', cursor: 'pointer',
                  border: 'none', background: 'none', color: dashboardView === 'daily' ? 'var(--primary)' : 'var(--text-secondary)',
                  borderBottom: dashboardView === 'daily' ? '3px solid var(--primary)' : '3px solid transparent',
                  transition: 'all 0.2s'
                }}
              >
                📅 Daily Moment
              </button>
              <button
                onClick={() => setDashboardView('range')}
                style={{
                  padding: '10px 24px', fontWeight: '700', fontSize: '0.88rem', cursor: 'pointer',
                  border: 'none', background: 'none', color: dashboardView === 'range' ? 'var(--primary)' : 'var(--text-secondary)',
                  borderBottom: dashboardView === 'range' ? '3px solid var(--primary)' : '3px solid transparent',
                  transition: 'all 0.2s'
                }}
              >
                📦 All Packages
              </button>
            </div>

            {/* ====== DAILY MOMENT VIEW ====== */}
            {dashboardView === 'daily' && (
              <>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px', alignItems: 'center', marginBottom: '20px' }}>
                  <div className="mgmt-form-group" style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <Calendar size={18} color="var(--primary)" />
                    <span style={{ fontWeight: '600', fontSize: '0.9rem' }}>{t('selectDate')}:</span>
                    <input type="date" className="mgmt-input" style={{ width: '180px', padding: '6px 12px' }} value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} />
                  </div>
                </div>

                <h3 style={{ fontFamily: 'var(--font-title)', fontSize: '1.25rem', fontWeight: '800', marginBottom: '14px', color: 'var(--navy)' }}>
                  {t('activeTours')} ({activeTours.length})
                </h3>

                {activeTours.length === 0 ? (
                  <div className="mgmt-empty-state">
                    <Calendar size={48} style={{ opacity: 0.3, marginBottom: '12px' }} />
                    <p>{t('noActiveTours')}</p>
                  </div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                    {activeTours.map((tour) => {
                      const isExpanded = expandedTourCode === tour.tourCode;
                      const startDateObj = new Date(tour.startDate);
                      const currDateObj = new Date(selectedDate);
                      const dayIndex = Math.floor((currDateObj - startDateObj) / (1000 * 3600 * 24));
                      const currentDayItinerary = tour.itinerary?.[dayIndex] || null;

                      return (
                        <div key={tour.tourCode} className="mgmt-card" style={{ padding: '20px' }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px' }}>
                            <div>
                              <h4 style={{ fontSize: '1.1rem', fontWeight: '800', color: 'var(--navy)' }}>{tour.tourName} ({tour.tourCode})</h4>
                              <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>Guest: {tour.clientName} ({tour.pax} Pax)</p>
                              <p style={{ fontSize: '0.82rem', color: 'var(--primary)', fontWeight: '600', marginTop: '4px' }}>
                                Current Location Today: {currentDayItinerary?.city || 'Not Specified'}
                              </p>
                            </div>
                            <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                              <button className="btn-secondary" style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '6px 12px', fontSize: '0.82rem' }} onClick={() => setPrintTour(tour)}>
                                <Printer size={14} /> Print PDF
                              </button>
                              <button className="btn-ghost" onClick={() => setExpandedTourCode(isExpanded ? null : tour.tourCode)}>
                                {isExpanded ? 'Collapse' : 'Manage Crew'}
                              </button>
                            </div>
                          </div>

                          {isExpanded && (
                            <div style={{ marginTop: '16px', paddingTop: '16px', borderTop: '1px dashed var(--border)', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                                <div>
                                  <label style={{ fontSize: '0.75rem', fontWeight: '700', textTransform: 'uppercase', color: 'var(--text-secondary)' }}>{t('guide')}</label>
                                  <select className="mgmt-select" value={tour.guideName} onChange={(e) => handleSwapGuide(tour.tourCode, e.target.value)}>
                                    {guides.map(g => {
                                      const isBusy = isGuideBusyOnDates(g.name, tour.startDate, tour.endDate);
                                      return (
                                        <option key={g.id} value={g.name}>
                                          {g.name} {isBusy ? `(${t('busyStatus')})` : `(${t('availableStatus')})`}
                                        </option>
                                      );
                                    })}
                                  </select>
                                </div>
                                <div>
                                  <label style={{ fontSize: '0.75rem', fontWeight: '700', textTransform: 'uppercase', color: 'var(--text-secondary)' }}>{t('driver')}</label>
                                  <select className="mgmt-select" value={tour.driverName} onChange={(e) => handleSwapDriver(tour.tourCode, e.target.value)}>
                                    {drivers.map(d => (
                                      <option key={d.id} value={d.name}>
                                        {d.name} ({d.vehicleType})
                                      </option>
                                    ))}
                                  </select>
                                </div>
                              </div>
                              <button 
                                className="btn-primary" 
                                style={{ marginTop: '14px', width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', padding: '10px' }}
                                onClick={() => setEditingTour(JSON.parse(JSON.stringify(tour)))}
                              >
                                ✏️ Edit Tour Itinerary & Details
                              </button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </>
            )}

            {/* ====== ALL PACKAGES (DATE RANGE + CITY FILTER) VIEW ====== */}
            {dashboardView === 'range' && (
              <>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '14px', alignItems: 'center', marginBottom: '20px', padding: '16px', background: 'var(--glass-bg)', borderRadius: '12px', border: '1px solid var(--border)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ fontWeight: '600', fontSize: '0.85rem' }}>From:</span>
                    <input type="date" className="mgmt-input" style={{ width: '160px', padding: '6px 12px' }} value={rangeFrom} onChange={(e) => setRangeFrom(e.target.value)} />
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ fontWeight: '600', fontSize: '0.85rem' }}>To:</span>
                    <input type="date" className="mgmt-input" style={{ width: '160px', padding: '6px 12px' }} value={rangeTo} onChange={(e) => setRangeTo(e.target.value)} />
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ fontWeight: '600', fontSize: '0.85rem' }}>City:</span>
                    <select className="mgmt-select" style={{ width: '180px', padding: '6px 12px' }} value={rangeCityFilter} onChange={(e) => setRangeCityFilter(e.target.value)}>
                      <option value="">All Cities</option>
                      {allTourCities.sort().map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                  <button className="btn-secondary" style={{ padding: '6px 16px', fontSize: '0.82rem' }} onClick={() => { setRangeFrom(''); setRangeTo(''); setRangeCityFilter(''); }}>
                    Clear Filters
                  </button>
                </div>

                <h3 style={{ fontFamily: 'var(--font-title)', fontSize: '1.25rem', fontWeight: '800', marginBottom: '14px', color: 'var(--navy)' }}>
                  All Packages ({rangeTours.length})
                </h3>

                {rangeTours.length === 0 ? (
                  <div className="mgmt-empty-state">
                    <Clipboard size={48} style={{ opacity: 0.3, marginBottom: '12px' }} />
                    <p>No packages found for the selected filters.</p>
                  </div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                    {rangeTours.map((tour) => (
                      <div key={tour.tourCode} className="mgmt-card" style={{ padding: '18px' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px', alignItems: 'center' }}>
                          <div>
                            <h4 style={{ fontSize: '1.05rem', fontWeight: '800', color: 'var(--navy)' }}>{tour.tourName} ({tour.tourCode})</h4>
                            <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)' }}>
                              {tour.clientName} • {tour.pax} Pax • {tour.startDate} → {tour.endDate}
                            </p>
                            <p style={{ fontSize: '0.78rem', color: 'var(--primary)', marginTop: '4px' }}>
                              Cities: {[...new Set((tour.itinerary || []).map(d => d.city).filter(Boolean))].join(' → ')}
                            </p>
                          </div>
                          <div style={{ display: 'flex', gap: '8px' }}>
                            <button className="btn-secondary" style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '6px 12px', fontSize: '0.8rem' }} onClick={() => setPrintTour(tour)}>
                              <Printer size={14} /> Print
                            </button>
                            <button className="btn-primary" style={{ padding: '6px 14px', fontSize: '0.8rem' }} onClick={() => setEditingTour(JSON.parse(JSON.stringify(tour)))}>
                              ✏️ Edit
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        )}

        {/* TAB 2: CITIES */}
        {activeTab === 'cities' && (
          <div className="mgmt-content">
            <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px', marginBottom: '20px' }}>
              <div className="mgmt-search-bar" style={{ marginBottom: 0 }}>
                <Compass size={18} />
                <input type="text" placeholder={t('searchPlaceholder')} value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
              </div>
              <button className="btn-primary" onClick={() => setShowAddForm(!showAddForm)}>
                <Plus size={16} /> {showAddForm ? t('close') : t('addCity')}
              </button>
            </div>

            {showAddForm && (
              <form onSubmit={handleAddCity} className="mgmt-form">
                <h3 style={{ fontFamily: 'var(--font-title)', fontWeight: '800' }}>{t('addCity')}</h3>
                <div className="mgmt-form-row">
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>{t('cityName')}</label>
                    <input className="mgmt-input" required value={newCity.name} onChange={(e) => setNewCity({ ...newCity, name: e.target.value })} />
                  </div>
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>{t('cityTagline')}</label>
                    <input className="mgmt-input" value={newCity.tagline} onChange={(e) => setNewCity({ ...newCity, tagline: e.target.value })} />
                  </div>
                </div>
                <div className="mgmt-form-row">
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>{t('bestTime')}</label>
                    <input className="mgmt-input" value={newCity.bestTime} onChange={(e) => setNewCity({ ...newCity, bestTime: e.target.value })} />
                  </div>
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>{t('languages')}</label>
                    <input className="mgmt-input" value={newCity.language} onChange={(e) => setNewCity({ ...newCity, language: e.target.value })} />
                  </div>
                </div>
                <div className="mgmt-form-row">
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>{t('currencyLabel')}</label>
                    <input className="mgmt-input" value={newCity.currency} onChange={(e) => setNewCity({ ...newCity, currency: e.target.value })} />
                  </div>
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>{t('transportOptions')}</label>
                    <input className="mgmt-input" value={newCity.transport} onChange={(e) => setNewCity({ ...newCity, transport: e.target.value })} />
                  </div>
                </div>
                <div>
                  <label className="login-label" style={{ color: 'var(--text-primary)' }}>{t('cityDescription')}</label>
                  <textarea className="mgmt-textarea" rows={3} value={newCity.description} onChange={(e) => setNewCity({ ...newCity, description: e.target.value })} />
                </div>
                <div className="mgmt-form-row">
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>{t('imageUrl')}</label>
                    <input className="mgmt-input" value={newCity.imageUrl} onChange={(e) => setNewCity({ ...newCity, imageUrl: e.target.value })} onPaste={(e) => handleImagePaste(e, (url) => setNewCity({ ...newCity, imageUrl: url }))} placeholder="Paste Image (Ctrl+V) or Enter URL" />
                  </div>
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>{t('googleMapsUrl')}</label>
                    <input className="mgmt-input" value={newCity.mapUrl} onChange={(e) => setNewCity({ ...newCity, mapUrl: e.target.value })} />
                  </div>
                </div>
                <button type="submit" className="btn-primary" style={{ alignSelf: 'flex-start' }}>{t('save')}</button>
              </form>
            )}

            <div className="mgmt-grid">
              {filteredCities.map((city) => (
                <div key={city.id} className="mgmt-card">
                  <div className="mgmt-card-img" style={{ backgroundImage: `url(${city.imageUrl || 'https://images.unsplash.com/photo-1596422847122-c3255789f9a3?w=800'})` }} />
                  <div className="mgmt-card-body">
                    <h4 className="mgmt-card-title">{city.name}</h4>
                    <p className="mgmt-card-subtitle">{city.tagline}</p>
                    <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginBottom: '16px', display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                      {city.description}
                    </p>
                    <div className="mgmt-card-actions">
                      <button className="btn-ghost" onClick={() => { if (confirm(t('confirmDelete'))) deleteCity(city.id); }} style={{ color: 'var(--danger)' }}>
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: ACTIVITIES */}
        {activeTab === 'activities' && (
          <div className="mgmt-content">
            <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px', marginBottom: '20px' }}>
              <div style={{ display: 'flex', gap: '10px', flex: 1, maxWidth: '500px' }}>
                <select className="mgmt-select" style={{ width: '180px' }} value={cityFilter} onChange={(e) => setCityFilter(e.target.value)}>
                  <option value="">All Cities</option>
                  {cities.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                </select>
                <div className="mgmt-search-bar" style={{ marginBottom: 0, flex: 1 }}>
                  <Compass size={18} />
                  <input type="text" placeholder={t('searchPlaceholder')} value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
                </div>
              </div>
              <button className="btn-primary" onClick={() => setShowAddForm(!showAddForm)}>
                <Plus size={16} /> {showAddForm ? t('close') : t('addActivity')}
              </button>
            </div>

            {showAddForm && (
              <form onSubmit={handleAddActivity} className="mgmt-form">
                <h3 style={{ fontFamily: 'var(--font-title)', fontWeight: '800' }}>{t('addActivity')}</h3>
                <div className="mgmt-form-row">
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>{t('city')}</label>
                    <select className="mgmt-select" required value={newActivity.city} onChange={(e) => setNewActivity({ ...newActivity, city: e.target.value })}>
                      <option value="">Select City</option>
                      {cities.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>{t('activityTitle')}</label>
                    <input className="mgmt-input" required value={newActivity.title} onChange={(e) => setNewActivity({ ...newActivity, title: e.target.value })} />
                  </div>
                </div>
                <div className="mgmt-form-row">
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>{t('estimatedTime')}</label>
                    <input className="mgmt-input" value={newActivity.time} onChange={(e) => setNewActivity({ ...newActivity, time: e.target.value })} />
                  </div>
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>{t('imageUrl')}</label>
                     <input className="mgmt-input" value={newActivity.imageUrl} onChange={(e) => setNewActivity({ ...newActivity, imageUrl: e.target.value })} onPaste={(e) => handleImagePaste(e, (url) => setNewActivity({ ...newActivity, imageUrl: url }))} placeholder="Paste Image (Ctrl+V) or Enter URL" />
                  </div>
                </div>
                <div>
                  <label className="login-label" style={{ color: 'var(--text-primary)' }}>{t('activityDesc')}</label>
                  <textarea className="mgmt-textarea" rows={3} value={newActivity.description} onChange={(e) => setNewActivity({ ...newActivity, description: e.target.value })} />
                </div>
                <button type="submit" className="btn-primary" style={{ alignSelf: 'flex-start' }}>{t('save')}</button>
              </form>
            )}

            <div className="mgmt-grid">
              {filteredActivities.map((act) => (
                <div key={act.id} className="mgmt-card">
                  <div className="mgmt-card-img" style={{ backgroundImage: `url(${act.imageUrl || 'https://images.unsplash.com/photo-1605649487212-47bdab064df7?w=800'})` }}>
                    <span className="mgmt-card-badge"><Calendar size={12} /> {act.time}</span>
                  </div>
                  <div className="mgmt-card-body">
                    <h4 className="mgmt-card-title">{act.title}</h4>
                    <p className="mgmt-card-subtitle">{act.city}</p>
                    <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginBottom: '16px' }}>{act.description}</p>
                    <div className="mgmt-card-actions">
                      <button className="btn-ghost" onClick={() => { if (confirm(t('confirmDelete'))) deleteActivity(act.id); }} style={{ color: 'var(--danger)' }}>
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: HOTELS */}
        {activeTab === 'hotels' && (
          <div className="mgmt-content">
            <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px', marginBottom: '20px' }}>
              <div style={{ display: 'flex', gap: '10px', flex: 1, maxWidth: '500px' }}>
                <select className="mgmt-select" style={{ width: '180px' }} value={cityFilter} onChange={(e) => setCityFilter(e.target.value)}>
                  <option value="">All Cities</option>
                  {cities.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                </select>
                <div className="mgmt-search-bar" style={{ marginBottom: 0, flex: 1 }}>
                  <Compass size={18} />
                  <input type="text" placeholder={t('searchPlaceholder')} value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
                </div>
              </div>
              <button className="btn-primary" onClick={() => setShowAddForm(!showAddForm)}>
                <Plus size={16} /> {showAddForm ? t('close') : t('addHotel')}
              </button>
            </div>

            {showAddForm && (
              <form onSubmit={handleAddHotel} className="mgmt-form">
                <h3 style={{ fontFamily: 'var(--font-title)', fontWeight: '800' }}>{t('addHotel')}</h3>
                <div className="mgmt-form-row">
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>{t('city')}</label>
                    <select className="mgmt-select" required value={newHotel.city} onChange={(e) => setNewHotel({ ...newHotel, city: e.target.value })}>
                      <option value="">Select City</option>
                      {cities.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>{t('hotelName')}</label>
                    <input className="mgmt-input" required value={newHotel.name} onChange={(e) => setNewHotel({ ...newHotel, name: e.target.value })} />
                  </div>
                </div>
                <div className="mgmt-form-row">
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>{t('starRating')}</label>
                    <select className="mgmt-select" value={newHotel.stars} onChange={(e) => setNewHotel({ ...newHotel, stars: parseInt(e.target.value) })}>
                      <option value={3}>3 Star Comfort</option>
                      <option value={4}>4 Star Premium</option>
                      <option value={5}>5 Star Luxury</option>
                    </select>
                  </div>
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>{t('receptionPhone')}</label>
                    <input className="mgmt-input" value={newHotel.phone} onChange={(e) => setNewHotel({ ...newHotel, phone: e.target.value })} />
                  </div>
                </div>
                <div className="mgmt-form-row">
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>Address</label>
                    <input className="mgmt-input" value={newHotel.address} onChange={(e) => setNewHotel({ ...newHotel, address: e.target.value })} />
                  </div>
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>Check In/Out Times</label>
                    <input className="mgmt-input" value={newHotel.checkInOut} onChange={(e) => setNewHotel({ ...newHotel, checkInOut: e.target.value })} />
                  </div>
                </div>

                <div>
                  <label className="login-label" style={{ color: 'var(--text-primary)', marginBottom: '8px', display: 'block' }}>{t('amenitiesLabel')}</label>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: '10px' }}>
                    {Object.keys(newHotel.amenities).map((am) => (
                      <label key={am} style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.8rem', color: 'var(--text-primary)' }}>
                        <input type="checkbox" checked={newHotel.amenities[am]} onChange={(e) => setNewHotel({
                          ...newHotel,
                          amenities: { ...newHotel.amenities, [am]: e.target.checked }
                        })} />
                        {am}
                      </label>
                    ))}
                  </div>
                </div>

                <div className="mgmt-form-row">
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>Image URL</label>
                     <input className="mgmt-input" value={newHotel.imageUrl} onChange={(e) => setNewHotel({ ...newHotel, imageUrl: e.target.value })} onPaste={(e) => handleImagePaste(e, (url) => setNewHotel({ ...newHotel, imageUrl: url }))} placeholder="Paste Image (Ctrl+V) or Enter URL" />
                  </div>
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>Google Maps URL</label>
                    <input className="mgmt-input" value={newHotel.mapUrl} onChange={(e) => setNewHotel({ ...newHotel, mapUrl: e.target.value })} />
                  </div>
                </div>
                <button type="submit" className="btn-primary" style={{ alignSelf: 'flex-start' }}>{t('save')}</button>
              </form>
            )}

            <div className="mgmt-grid">
              {filteredHotels.map((hotel) => (
                <div key={hotel.id} className="mgmt-card">
                  <div className="mgmt-card-img" style={{ backgroundImage: `url(${hotel.imageUrl || 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?w=800'})` }}>
                    <span className="mgmt-card-badge" style={{ color: '#eab308' }}>
                      <Star size={12} fill="currentColor" /> {hotel.stars} Stars
                    </span>
                  </div>
                  <div className="mgmt-card-body">
                    <h4 className="mgmt-card-title">{hotel.name}</h4>
                    <p className="mgmt-card-subtitle">{hotel.city}</p>
                    <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginBottom: '8px' }}>Phone: {hotel.phone}</p>
                    <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginBottom: '16px' }}>Address: {hotel.address}</p>

                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px', marginBottom: '16px' }}>
                      {Array.isArray(hotel.amenities) && hotel.amenities.map(am => (
                        <span key={am} style={{ fontSize: '0.68rem', backgroundColor: 'var(--bg-primary)', padding: '2px 8px', borderRadius: '4px', fontWeight: '600' }}>{am}</span>
                      ))}
                    </div>

                    <div className="mgmt-card-actions">
                      <button className="btn-ghost" onClick={() => { if (confirm(t('confirmDelete'))) deleteHotel(hotel.id); }} style={{ color: 'var(--danger)' }}>
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 5: GUIDES */}
        {activeTab === 'guides' && (
          <div className="mgmt-content">
            <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px', marginBottom: '20px' }}>
              <div className="mgmt-search-bar" style={{ marginBottom: 0 }}>
                <Compass size={18} />
                <input type="text" placeholder={t('searchPlaceholder')} value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
              </div>
              <button className="btn-primary" onClick={() => setShowAddForm(!showAddForm)}>
                <Plus size={16} /> {showAddForm ? t('close') : 'Add New Guide'}
              </button>
            </div>

            {showAddForm && (
              <form onSubmit={handleAddGuide} className="mgmt-form">
                <h3 style={{ fontFamily: 'var(--font-title)', fontWeight: '800' }}>Add New Guide</h3>
                <div className="mgmt-form-row">
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>Guide Name</label>
                    <input className="mgmt-input" required value={newGuide.name} onChange={(e) => setNewGuide({ ...newGuide, name: e.target.value })} />
                  </div>
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>Mobile Number</label>
                    <input className="mgmt-input" required value={newGuide.mobile} onChange={(e) => setNewGuide({ ...newGuide, mobile: e.target.value })} />
                  </div>
                </div>
                <button type="submit" className="btn-primary" style={{ alignSelf: 'flex-start' }}>{t('save')}</button>
              </form>
            )}

            <div className="mgmt-grid">
              {guides.filter(g => g.name.toLowerCase().includes(searchQuery.toLowerCase())).map((g) => {
                const busyList = guideBusyStates[g.name] || [];
                const isCurrentlyBusy = busyList.some(b => {
                  const now = new Date();
                  return now >= new Date(b.startDate) && now <= new Date(b.endDate);
                });

                return (
                  <div key={g.id} className="mgmt-card" style={{ padding: '16px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div>
                        <h4 style={{ fontWeight: '700', color: 'var(--navy)' }}>{g.name}</h4>
                        <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginTop: '4px' }}>Mobile: {g.mobile}</p>
                      </div>
                      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '8px' }}>
                        {isCurrentlyBusy ? (
                          <span className="busy-badge">BUSY</span>
                        ) : (
                          <span className="available-badge">AVAILABLE</span>
                        )}
                        <button className="btn-ghost" onClick={() => { if (confirm(t('confirmDelete'))) deleteGuide(g.id); }} style={{ color: 'var(--danger)', padding: '4px' }}>
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 6: DRIVERS */}
        {activeTab === 'drivers' && (
          <div className="mgmt-content">
            <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px', marginBottom: '20px' }}>
              <div className="mgmt-search-bar" style={{ marginBottom: 0 }}>
                <Compass size={18} />
                <input type="text" placeholder={t('searchPlaceholder')} value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
              </div>
              <button className="btn-primary" onClick={() => setShowAddForm(!showAddForm)}>
                <Plus size={16} /> {showAddForm ? t('close') : 'Add New Driver'}
              </button>
            </div>

            {showAddForm && (
              <form onSubmit={handleAddDriver} className="mgmt-form">
                <h3 style={{ fontFamily: 'var(--font-title)', fontWeight: '800' }}>Add New Driver</h3>
                <div className="mgmt-form-row">
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>Driver Name</label>
                    <input className="mgmt-input" required value={newDriver.name} onChange={(e) => setNewDriver({ ...newDriver, name: e.target.value })} />
                  </div>
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>Mobile Number</label>
                    <input className="mgmt-input" required value={newDriver.mobile} onChange={(e) => setNewDriver({ ...newDriver, mobile: e.target.value })} />
                  </div>
                </div>
                <div className="mgmt-form-row">
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>Vehicle Registration Number</label>
                    <input className="mgmt-input" required value={newDriver.carNumber} onChange={(e) => setNewDriver({ ...newDriver, carNumber: e.target.value })} />
                  </div>
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>Vehicle Type</label>
                    <select className="mgmt-select" value={newDriver.vehicleType} onChange={(e) => setNewDriver({ ...newDriver, vehicleType: e.target.value })}>
                      <option value="Toyota Innova Crysta (SUV)">Toyota Innova Crysta (SUV)</option>
                      <option value="Tempo Traveller (Mini Bus)">Tempo Traveller (Mini Bus)</option>
                      <option value="Force Urbania (Luxury Van)">Force Urbania (Luxury Van)</option>
                      <option value="Toyota Etios (Sedan)">Toyota Etios (Sedan)</option>
                      <option value="Mercedes Benz (Luxury Sedan)">Mercedes Benz (Luxury Sedan)</option>
                      <option value="Maruti Ertiga (Hatchback)">Maruti Ertiga (Hatchback)</option>
                    </select>
                  </div>
                </div>
                <button type="submit" className="btn-primary" style={{ alignSelf: 'flex-start' }}>{t('save')}</button>
              </form>
            )}

            <div className="mgmt-grid">
              {drivers.filter(d => d.name.toLowerCase().includes(searchQuery.toLowerCase())).map((d) => (
                <div key={d.id} className="mgmt-card" style={{ padding: '16px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                      <h4 style={{ fontWeight: '700', color: 'var(--navy)' }}>{d.name}</h4>
                      <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginTop: '4px' }}>Reg: {d.carNumber || d.reg}</p>
                      <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Type: {d.vehicleType || d.type}</p>
                      <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Mobile: {d.mobile}</p>
                    </div>
                    <button className="btn-ghost" onClick={() => { if (confirm(t('confirmDelete'))) deleteDriver(d.id); }} style={{ color: 'var(--danger)' }}>
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 7: RESTAURANTS */}
        {activeTab === 'restaurants' && (
          <div className="mgmt-content">
            <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px', marginBottom: '20px' }}>
              <div style={{ display: 'flex', gap: '10px', flex: 1, maxWidth: '500px' }}>
                <select className="mgmt-select" style={{ width: '180px' }} value={cityFilter} onChange={(e) => setCityFilter(e.target.value)}>
                  <option value="">All Cities</option>
                  {cities.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                </select>
                <div className="mgmt-search-bar" style={{ marginBottom: 0, flex: 1 }}>
                  <UtensilsCrossed size={18} />
                  <input type="text" placeholder="Search restaurants..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
                </div>
              </div>
              <button className="btn-primary" onClick={() => setShowAddForm(!showAddForm)}>
                <Plus size={16} /> {showAddForm ? t('close') : 'Add Restaurant'}
              </button>
            </div>

            {showAddForm && (
              <form onSubmit={handleAddRestaurant} className="mgmt-form">
                <h3 style={{ fontFamily: 'var(--font-title)', fontWeight: '800' }}>Add Local Restaurant</h3>
                <div className="mgmt-form-row">
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>City</label>
                    <select className="mgmt-select" required value={newRestaurant.city} onChange={(e) => setNewRestaurant({ ...newRestaurant, city: e.target.value })}>
                      <option value="">Select City</option>
                      {cities.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>Restaurant Name</label>
                    <input className="mgmt-input" required value={newRestaurant.name} onChange={(e) => setNewRestaurant({ ...newRestaurant, name: e.target.value })} />
                  </div>
                </div>
                <div className="mgmt-form-row">
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>Meal Type</label>
                    <select className="mgmt-select" value={newRestaurant.mealType} onChange={(e) => setNewRestaurant({ ...newRestaurant, mealType: e.target.value })}>
                      <option value="Breakfast">Breakfast</option>
                      <option value="Lunch">Lunch</option>
                      <option value="Dinner">Dinner</option>
                    </select>
                  </div>
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>Cuisine Type</label>
                    <input className="mgmt-input" placeholder="e.g. Indian, Korean, Chinese" value={newRestaurant.cuisine} onChange={(e) => setNewRestaurant({ ...newRestaurant, cuisine: e.target.value })} />
                  </div>
                </div>
                <div className="mgmt-form-row">
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>Address</label>
                    <input className="mgmt-input" value={newRestaurant.address} onChange={(e) => setNewRestaurant({ ...newRestaurant, address: e.target.value })} />
                  </div>
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>Phone</label>
                    <input className="mgmt-input" value={newRestaurant.phone} onChange={(e) => setNewRestaurant({ ...newRestaurant, phone: e.target.value })} />
                  </div>
                </div>
                <div className="mgmt-form-row">
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>Google Maps URL</label>
                    <input className="mgmt-input" value={newRestaurant.mapUrl} onChange={(e) => setNewRestaurant({ ...newRestaurant, mapUrl: e.target.value })} />
                  </div>
                  <div>
                    <label className="login-label" style={{ color: 'var(--text-primary)' }}>Image URL</label>
                    <input className="mgmt-input" value={newRestaurant.imageUrl} onChange={(e) => setNewRestaurant({ ...newRestaurant, imageUrl: e.target.value })} onPaste={(e) => handleImagePaste(e, (url) => setNewRestaurant({ ...newRestaurant, imageUrl: url }))} placeholder="Paste Image (Ctrl+V) or Enter URL" />
                  </div>
                </div>
                <button type="submit" className="btn-primary" style={{ alignSelf: 'flex-start' }}>{t('save')}</button>
              </form>
            )}

            <div className="mgmt-grid">
              {restaurants.filter(r => {
                const matchesCity = cityFilter ? r.city === cityFilter : true;
                const matchesSearch = r.name.toLowerCase().includes(searchQuery.toLowerCase());
                return matchesCity && matchesSearch;
              }).map((r) => (
                <div key={r.id} className="mgmt-card" style={{ padding: '16px' }}>
                  {r.imageUrl && <div className="mgmt-card-img" style={{ backgroundImage: `url(${r.imageUrl})` }}>
                    <span className="mgmt-card-badge"><UtensilsCrossed size={12} /> {r.mealType}</span>
                  </div>}
                  <div className="mgmt-card-body">
                    <h4 className="mgmt-card-title">{r.name}</h4>
                    <p className="mgmt-card-subtitle">{r.city} • {r.cuisine}</p>
                    <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginTop: '4px' }}>{r.address}</p>
                    {r.phone && <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>📞 {r.phone}</p>}
                    <div className="mgmt-card-actions">
                      {r.mapUrl && <a href={r.mapUrl} target="_blank" rel="noopener noreferrer" className="btn-ghost" style={{ fontSize: '0.75rem' }}>📍 Map</a>}
                      <button className="btn-ghost" onClick={() => { if (confirm(t('confirmDelete'))) deleteRestaurant(r.id); }} style={{ color: 'var(--danger)' }}>
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 8: TOUR BUILDER */}
        {activeTab === 'tourBuilder' && (
          <div className="mgmt-content">
            <form onSubmit={handlePublishTour} className="mgmt-form" style={{ gap: '20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h3 style={{ fontFamily: 'var(--font-title)', fontWeight: '800', color: 'var(--navy)' }}>Tour Information</h3>
              </div>

              <div className="mgmt-form-row">
                <div>
                  <label className="login-label" style={{ color: 'var(--text-primary)' }}>Tour Code</label>
                  <input className="mgmt-input" required value={newTour.tourCode} onChange={(e) => setNewTour({ ...newTour, tourCode: e.target.value.toUpperCase() })} placeholder="e.g. TAJ-HJ-RAJASTHAN-TOUR" />
                </div>
                <div>
                  <label className="login-label" style={{ color: 'var(--text-primary)' }}>Tour Title / Name</label>
                  <input className="mgmt-input" required value={newTour.tourName} onChange={(e) => {
                    const title = e.target.value;
                    const code = title.trim().toUpperCase().replace(/[^A-Z0-9]/g, '-').replace(/-+/g, '-');
                    setNewTour({ ...newTour, tourName: title, tourCode: code });
                  }} placeholder="e.g. Golden Triangle Deluxe" />
                </div>
              </div>

              <div className="mgmt-form-row">
                <div>
                  <label className="login-label" style={{ color: 'var(--text-primary)' }}>Client Name</label>
                  <input className="mgmt-input" required value={newTour.clientName} onChange={(e) => setNewTour({ ...newTour, clientName: e.target.value })} placeholder="e.g. John Doe Family" />
                </div>
                <div>
                  <label className="login-label" style={{ color: 'var(--text-primary)' }}>No. of Passengers (Pax)</label>
                  <input type="number" className="mgmt-input" required value={newTour.pax} onChange={(e) => setNewTour({ ...newTour, pax: parseInt(e.target.value) })} />
                </div>
              </div>

              <div className="mgmt-form-row">
                <div>
                  <label className="login-label" style={{ color: 'var(--text-primary)' }}>Start Date</label>
                  <input type="date" className="mgmt-input" required value={newTour.startDate} onChange={(e) => setNewTour({ ...newTour, startDate: e.target.value })} />
                </div>
                <div>
                  <label className="login-label" style={{ color: 'var(--text-primary)' }}>End Date</label>
                  <input type="date" className="mgmt-input" required value={newTour.endDate} onChange={(e) => setNewTour({ ...newTour, endDate: e.target.value })} />
                </div>
              </div>

              <div className="mgmt-form-row">
                <div>
                  <label className="login-label" style={{ color: 'var(--text-primary)' }}>Assigned Guide</label>
                  <select className="mgmt-select" required value={newTour.guideName} onChange={(e) => setNewTour({ ...newTour, guideName: e.target.value })}>
                    <option value="">Select Guide</option>
                    {guides.map(g => {
                      const isBusy = isGuideBusyOnDates(g.name, newTour.startDate, newTour.endDate);
                      return (
                        <option key={g.id} value={g.name}>
                          {g.name} {isBusy ? `(${t('busyStatus')})` : `(${t('availableStatus')})`}
                        </option>
                      );
                    })}
                  </select>
                </div>
                <div>
                  <label className="login-label" style={{ color: 'var(--text-primary)' }}>Assigned Driver & Car</label>
                  <select className="mgmt-select" required value={newTour.driverName} onChange={(e) => setNewTour({ ...newTour, driverName: e.target.value })}>
                    <option value="">Select Driver</option>
                    {drivers.map(d => (
                      <option key={d.id} value={d.name}>{d.name} ({d.vehicleType || d.type})</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Master Itinerary Template Selector */}
              <div style={{ marginTop: '16px', padding: '16px', background: 'linear-gradient(135deg, rgba(255,215,0,0.08), rgba(200,160,60,0.06))', borderRadius: '12px', border: '1px solid rgba(200,160,60,0.25)' }}>
                <label className="login-label" style={{ color: 'var(--navy)', fontWeight: '800', fontSize: '0.9rem', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  📋 Load Master Itinerary Template
                </label>
                <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', margin: '4px 0 10px' }}>
                  Select a pre-built template to auto-fill the itinerary. You can then customize dates, flights, transport, driver, hotel etc.
                </p>
                <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
                  {MASTER_ITINERARIES.map(mi => (
                    <button
                      key={mi.id}
                      type="button"
                      onClick={() => applyMasterItinerary(mi.id)}
                      disabled={!newTour.startDate}
                      style={{
                        padding: '10px 18px', borderRadius: '8px', fontSize: '0.84rem', fontWeight: '700', cursor: 'pointer',
                        border: selectedMasterItinerary === mi.id ? '2px solid var(--primary)' : '1px solid var(--border)',
                        background: selectedMasterItinerary === mi.id ? 'var(--primary)' : 'white',
                        color: selectedMasterItinerary === mi.id ? '#fff' : 'var(--navy)',
                        opacity: !newTour.startDate ? 0.5 : 1, transition: 'all 0.2s'
                      }}
                    >
                      {mi.name}
                    </button>
                  ))}
                </div>
                {!newTour.startDate && <p style={{ fontSize: '0.75rem', color: '#d44', marginTop: '6px' }}>⚠️ Please set Start Date first before loading a template.</p>}
              </div>

              <h4 style={{ fontFamily: 'var(--font-title)', fontWeight: '800', marginTop: '16px', color: 'var(--navy)' }}>Itinerary Plan</h4>

              {itineraryDays.map((day, idx) => {
                const hotelsInCity = hotels.filter(h => h.city === day.city);
                const activitiesInCity = activities.filter(a => a.city === day.city);

                return (
                  <div key={idx} className="itin-day-card">
                    <div className="itin-day-header">
                      <span style={{ fontWeight: '700' }}>Day {day.day} ({day.dateStr})</span>
                    </div>

                    <div className="mgmt-form-row" style={{ marginBottom: '12px' }}>
                      <div>
                        <label className="login-label" style={{ color: 'var(--text-primary)', fontSize: '0.78rem' }}>City Location</label>
                        <select className="mgmt-select" value={day.city} onChange={(e) => {
                          const updated = [...itineraryDays];
                          updated[idx].city = e.target.value;
                          updated[idx].hotelName = ''; // Reset hotel when city changes
                          const cityObj = cities.find(c => c.name === e.target.value);
                          updated[idx].coverImage = cityObj?.imageUrl || '';
                          setItineraryDays(updated);
                        }}>
                          {cities.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                        </select>
                      </div>

                      <div>
                        <label className="login-label" style={{ color: 'var(--text-primary)', fontSize: '0.78rem' }}>Overnight Hotel</label>
                        <select className="mgmt-select" value={day.hotelName} onChange={(e) => {
                          const updated = [...itineraryDays];
                          updated[idx].hotelName = e.target.value;
                          const h = hotels.find(hotel => hotel.name === e.target.value);
                          updated[idx].hotelAddress = h?.address || '';
                          updated[idx].hotelMapLink = h?.mapUrl || '';
                          setItineraryDays(updated);
                        }}>
                          <option value="">No Hotel / In-Transit</option>
                          {hotelsInCity.map(h => <option key={h.id} value={h.name}>{h.name}</option>)}
                        </select>
                      </div>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: '12px', marginBottom: '12px' }}>
                      <div>
                        <label className="login-label" style={{ color: 'var(--text-primary)', fontSize: '0.78rem' }}>Activities Checklist (Select for Client View)</label>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginTop: '6px' }}>
                          {activitiesInCity.map(act => {
                            const isSelected = day.activitiesList.some(item => item.title === act.title);
                            return (
                              <button
                                key={act.id}
                                type="button"
                                onClick={() => {
                                  const updated = [...itineraryDays];
                                  const list = [...updated[idx].activitiesList];
                                  const matchIndex = list.findIndex(item => item.title === act.title);
                                  if (matchIndex > -1) {
                                    list.splice(matchIndex, 1);
                                  } else {
                                    list.push({ time: '09:00 AM', title: act.title });
                                  }
                                  updated[idx].activitiesList = list;
                                  setItineraryDays(updated);
                                }}
                                style={{
                                  fontSize: '0.72rem',
                                  padding: '4px 10px',
                                  borderRadius: '6px',
                                  border: '1px solid var(--border)',
                                  backgroundColor: isSelected ? 'var(--primary-light)' : 'white',
                                  color: isSelected ? 'var(--primary-dark)' : 'var(--text-secondary)',
                                  cursor: 'pointer'
                                }}
                              >
                                {isSelected ? '✓ ' : ''}{act.title}
                              </button>
                            );
                          })}
                        </div>

                        {/* Time inputs for selected activities */}
                        {day.activitiesList.length > 0 && (
                          <div style={{ marginTop: '12px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                            <label className="login-label" style={{ color: 'var(--text-primary)', fontSize: '0.78rem', fontWeight: '700' }}>⏰ Set Activity Times (shown to Driver & Client)</label>
                            {day.activitiesList.map((act, actIdx) => (
                              <div key={actIdx} style={{ display: 'flex', alignItems: 'center', gap: '10px', backgroundColor: '#f8fafc', padding: '8px 12px', borderRadius: '8px', border: '1px solid var(--border-light)' }}>
                                <input
                                  type="time"
                                  className="mgmt-input"
                                  style={{ width: '120px', padding: '6px 8px', fontSize: '0.82rem' }}
                                  value={(() => {
                                    // Convert "09:00 AM" format to "09:00" for input
                                    const t = act.time || '09:00 AM';
                                    const match = t.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
                                    if (match) {
                                      let h = parseInt(match[1]);
                                      const m = match[2];
                                      const ampm = match[3].toUpperCase();
                                      if (ampm === 'PM' && h !== 12) h += 12;
                                      if (ampm === 'AM' && h === 12) h = 0;
                                      return `${String(h).padStart(2, '0')}:${m}`;
                                    }
                                    return '09:00';
                                  })()}
                                  onChange={(e) => {
                                    const updated = [...itineraryDays];
                                    const val = e.target.value; // "14:30"
                                    const [hStr, mStr] = val.split(':');
                                    let h = parseInt(hStr);
                                    const ampm = h >= 12 ? 'PM' : 'AM';
                                    if (h > 12) h -= 12;
                                    if (h === 0) h = 12;
                                    const formatted = `${String(h).padStart(2, '0')}:${mStr} ${ampm}`;
                                    updated[idx].activitiesList[actIdx].time = formatted;
                                    setItineraryDays(updated);
                                  }}
                                />
                                <span style={{ flex: 1, fontSize: '0.82rem', fontWeight: '600', color: 'var(--text-primary)' }}>{act.title}</span>
                                <button
                                  type="button"
                                  onClick={() => {
                                    const updated = [...itineraryDays];
                                    updated[idx].activitiesList.splice(actIdx, 1);
                                    setItineraryDays(updated);
                                  }}
                                  style={{ background: 'none', border: 'none', color: 'var(--danger)', cursor: 'pointer', fontSize: '0.9rem' }}
                                >✕</button>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="mgmt-form-row">
                      <div>
                        <label className="login-label" style={{ color: 'var(--text-primary)', fontSize: '0.78rem' }}>Transport Mode</label>
                        <select className="mgmt-select" value={day.transport} onChange={(e) => {
                          const updated = [...itineraryDays];
                          updated[idx].transport = e.target.value;
                          if (e.target.value !== 'By Flight') updated[idx].flightNo = '';
                          if (e.target.value !== 'By Train') updated[idx].trainNo = '';
                          setItineraryDays(updated);
                        }}>
                          <option value="By Surface">By Surface (Chauffeur Car)</option>
                          <option value="By Train">By Train</option>
                          <option value="By Flight">By Flight</option>
                        </select>
                      </div>
                      <div>
                        <label className="login-label" style={{ color: 'var(--text-primary)', fontSize: '0.78rem' }}>Meal Plan</label>
                        <select className="mgmt-select" value={day.mealPlan} onChange={(e) => {
                          const updated = [...itineraryDays];
                          updated[idx].mealPlan = e.target.value;
                          setItineraryDays(updated);
                        }}>
                          {MEAL_PLAN_OPTIONS.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                        </select>
                      </div>
                    </div>

                    {day.transport === 'By Flight' && (
                      <div style={{ marginTop: '12px' }}>
                        <label className="login-label" style={{ color: 'var(--text-primary)', fontSize: '0.78rem' }}>✈️ Flight Number</label>
                        <input className="mgmt-input" placeholder="e.g. KE 497" value={day.flightNo || ''} onChange={(e) => {
                          const updated = [...itineraryDays];
                          updated[idx].flightNo = e.target.value;
                          setItineraryDays(updated);
                        }} />
                      </div>
                    )}
                    {day.transport === 'By Train' && (
                      <div style={{ marginTop: '12px' }}>
                        <label className="login-label" style={{ color: 'var(--text-primary)', fontSize: '0.78rem' }}>🚆 Train Number</label>
                        <input className="mgmt-input" placeholder="e.g. 12952 Rajdhani" value={day.trainNo || ''} onChange={(e) => {
                          const updated = [...itineraryDays];
                          updated[idx].trainNo = e.target.value;
                          setItineraryDays(updated);
                        }} />
                      </div>
                    )}

                    {/* Local Restaurant */}
                    <div className="mgmt-form-row" style={{ marginTop: '12px' }}>
                      <div>
                        <label className="login-label" style={{ color: 'var(--text-primary)', fontSize: '0.78rem' }}>🍽️ Local Restaurant</label>
                        <select className="mgmt-select" value={day.localRestaurant || ''} onChange={(e) => {
                          const updated = [...itineraryDays];
                          const rest = restaurants.find(r => r.name === e.target.value);
                          updated[idx].localRestaurant = e.target.value;
                          updated[idx].restaurantMealType = rest?.mealType || '';
                          updated[idx].restaurantMapUrl = rest?.mapUrl || '';
                          setItineraryDays(updated);
                        }}>
                          <option value="">No Restaurant Assigned</option>
                          {restaurants.filter(r => r.city === day.city).map(r => (
                            <option key={r.id} value={r.name}>{r.name} ({r.mealType} - {r.cuisine})</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div style={{ marginTop: '12px' }}>
                      <label className="login-label" style={{ color: 'var(--text-primary)', fontSize: '0.78rem' }}>Day Notes / Description</label>
                      <textarea className="mgmt-textarea" rows={2} value={day.activities} onChange={(e) => {
                        const updated = [...itineraryDays];
                        updated[idx].activities = e.target.value;
                        setItineraryDays(updated);
                      }} />
                    </div>
                  </div>
                );
              })}

              <button type="submit" className="btn-primary" style={{ alignSelf: 'center', width: '100%', maxWidth: '300px', padding: '14px' }}>
                Publish Tour & Itinerary
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
