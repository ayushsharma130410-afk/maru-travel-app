import React, { useState, useEffect, useRef } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { listenToTour, updateDriverLocation, submitComplaint, markDayArrived, updateTourResource } from '../services/firebase';
import { sendNotificationEmail } from '../services/email';
import { Navigation, Car, AlertOctagon, Phone, User, Play, Square, Check, MapPin, Calendar, Compass, Shield, Clock, ChevronRight, CheckCircle2, X, AlertTriangle, Truck, Printer } from 'lucide-react';

export default function DriverPortal({ tourCode, onLogout }) {
  const { t, language } = useLanguage();
  const [tourData, setTourData] = useState(null);
  
  // Coordinates mapping for cities
  const getCityCoords = (cityName) => {
    const coordsDb = {
      "New Delhi": { lat: 28.6139, lng: 77.2090 },
      "Agra": { lat: 27.1751, lng: 78.0421 },
      "Jaipur": { lat: 26.9124, lng: 75.7873 },
      "Jodhpur": { lat: 26.2912, lng: 73.0169 },
      "Udaipur": { lat: 24.5854, lng: 73.7125 },
      "Varanasi": { lat: 25.3176, lng: 82.9739 },
      "Mumbai": { lat: 18.9220, lng: 72.8347 },
      "Jaisalmer": { lat: 26.9157, lng: 70.9083 },
      "Khajuraho": { lat: 24.8318, lng: 79.9199 },
      "Shimla": { lat: 31.1048, lng: 77.1734 },
      "Manali": { lat: 32.2396, lng: 77.1887 },
      "Amritsar": { lat: 31.6340, lng: 74.8723 },
      "Kochi": { lat: 9.9312, lng: 76.2673 },
      "Munnar": { lat: 10.0889, lng: 77.0595 },
      "Chennai": { lat: 13.0827, lng: 80.2707 },
      "Lucknow": { lat: 26.8467, lng: 80.9462 },
      "Patna": { lat: 25.6093, lng: 85.1376 }
    };
    return coordsDb[cityName] || { lat: 27.1751, lng: 78.0421 };
  };

  // Simulation State
  const [isSimulating, setIsSimulating] = useState(false);
  const [coords, setCoords] = useState({ lat: 27.1685, lng: 78.0422 });
  const [showReportModal, setShowReportModal] = useState(false);

  // Reporting State
  const [problemCategory, setProblemCategory] = useState("Traffic");
  const [problemNote, setProblemNote] = useState("");
  const [isProblemSending, setIsProblemSending] = useState(false);
  const [problemSuccess, setProblemSuccess] = useState("");

  const [showPrintPreview, setShowPrintPreview] = useState(false);
  const activeDayRef = useRef(null);

  // Subscribe to tour details
  useEffect(() => {
    const unsubscribe = listenToTour(tourCode, (data) => {
      if (data) {
        setTourData(data);
        const initialCity = data.itinerary?.[0]?.city || "Agra";
        setCoords(getCityCoords(initialCity));
      }
    });
    return () => unsubscribe();
  }, [tourCode]);

  // GPS Coordinator Shift Simulation
  useEffect(() => {
    if (!isSimulating || !tourData) return;
    const currentCity = tourData.itinerary?.[0]?.city || "Agra";
    const baseCoords = getCityCoords(currentCity);

    let step = 0;
    const interval = setInterval(async () => {
      step += 0.0003;
      const nextLat = baseCoords.lat + Math.sin(step) * 0.004;
      const nextLng = baseCoords.lng + Math.cos(step) * 0.004;
      setCoords({ lat: nextLat, lng: nextLng });
      await updateDriverLocation(tourCode, nextLat, nextLng);
    }, 1800);

    return () => clearInterval(interval);
  }, [isSimulating, tourData, tourCode]);

  // Scroll to active day on load
  useEffect(() => {
    if (tourData && activeDayRef.current) {
      setTimeout(() => {
        activeDayRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 500);
    }
  }, [tourData]);

  const toggleSimulation = async () => {
    if (isSimulating) {
      setIsSimulating(false);
    } else {
      setIsSimulating(true);
      await updateDriverLocation(tourCode, coords.lat, coords.lng);
    }
  };

  const handleReportProblem = async (e) => {
    e.preventDefault();
    setIsProblemSending(true);
    setProblemSuccess("");

    const clientName = tourData?.clientName || "Valued Guest";
    const details = `DRIVER ALERT: ${problemCategory} — ${problemNote || 'No additional details'} | Reported by ${tourData?.driverName || 'Driver'}`;

    await submitComplaint({
      tourCode,
      clientName: clientName,
      type: 'DRIVER_ALERT',
      category: problemCategory,
      details: details
    });

    await sendNotificationEmail({
      tourCode,
      clientName: clientName,
      type: 'DRIVER_ALERT',
      category: problemCategory,
      details: details
    });

    setIsProblemSending(false);
    setProblemSuccess("Alert sent to headquarters!");
    setProblemNote("");
    setTimeout(() => {
      setProblemSuccess("");
      setShowReportModal(false);
    }, 2500);
  };

  const handleMarkArrived = async (dayIdx) => {
    const arrivalTime = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
    const arrivalDate = new Date().toISOString();
    await markDayArrived(tourCode, dayIdx);
    // Also update the arrival timestamp
    try {
      await updateTourResource(tourCode, `itinerary/${dayIdx}/arrivedAt`, arrivalTime);
      await updateTourResource(tourCode, `itinerary/${dayIdx}/arrivedTimestamp`, arrivalDate);
    } catch (e) {
      // Fallback: already marked via markDayArrived
    }
  };

  if (!tourData) {
    return (
      <div style={styles.loaderWrap}>
        <img src="/maru_logo.png" alt="Maru Travel" style={{ width: '120px', marginBottom: '16px', opacity: 0.9 }} />
        <div style={styles.spinner} />
        <p style={{ color: '#073549', fontWeight: '600' }}>Loading your itinerary...</p>
      </div>
    );
  }

  // Get active day index — today's date or first day
  const todayStr = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }).replace(/ /g, '-');
  const activeDayIndex = tourData.itinerary?.findIndex(d => d.dateStr === todayStr) ?? 0;
  const realActiveDayIdx = activeDayIndex === -1 ? 0 : activeDayIndex;
  const currentDay = tourData.itinerary?.[realActiveDayIdx] || {};
  const nextActivity = currentDay.activitiesList?.[0] || {};

  // Calculate how many activities are done (based on arrival)
  const totalDays = tourData.itinerary?.length || 1;
  const completedDays = tourData.itinerary?.filter(d => d.arrived).length || 0;

  if (showPrintPreview) {
    return (
      <div className="print-overlay" style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: '#f1f5f9', zIndex: 9999, overflowY: 'auto', display: 'flex', flexDirection: 'column' }}>
        <style>{`
          @media print {
            html, body, #root {
              width: auto !important;
              height: auto !important;
              overflow: visible !important;
              position: static !important;
              background: white !important;
              color: black !important;
            }
            .no-print {
              display: none !important;
            }
            @page {
              size: A4;
              margin: 0 !important;
            }
            #printable-area {
              margin: 0 !important;
              padding: 22mm !important;
              box-shadow: none !important;
              width: 100% !important;
              max-width: 100% !important;
              min-height: auto !important;
              display: block !important;
              position: static !important;
              border: none !important;
              background: white !important;
            }
            #printable-area table td,
            #printable-area table th {
              border-color: #000000 !important;
            }
            .print-page-border {
              display: none;
            }
            @media print {
              .print-page-border {
                display: block !important;
                position: fixed !important;
                top: 12mm !important;
                left: 12mm !important;
                right: 12mm !important;
                bottom: 12mm !important;
                border: 2px solid #000000 !important;
                z-index: 99999 !important;
                pointer-events: none !important;
                box-sizing: border-box !important;
              }
            }
          }
        `}</style>

        {/* Non-Printable Action Header */}
        <div className="no-print" style={{ height: '60px', backgroundColor: '#0B4F6C', color: '#FAF7F2', padding: '0 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', boxShadow: '0 2px 8px rgba(0,0,0,0.15)', flexShrink: 0 }}>
          <span style={{ fontWeight: '700', fontSize: '1rem' }}>PDF Tour Print Preview ({tourData.tourCode})</span>
          <div style={{ display: 'flex', gap: '12px' }}>
            <button onClick={() => window.print()} style={{ backgroundColor: '#10B981', color: 'white', border: 'none', padding: '8px 16px', borderRadius: '6px', fontWeight: '700', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.85rem' }}>
              <Printer size={16} /> Print Brief Itinerary
            </button>
            <button onClick={() => setShowPrintPreview(false)} style={{ backgroundColor: 'rgba(255,255,255,0.15)', color: 'white', border: '1px solid rgba(255,255,255,0.3)', padding: '8px 16px', borderRadius: '6px', fontWeight: '700', cursor: 'pointer', fontSize: '0.85rem' }}>
              ✕ Close Preview
            </button>
          </div>
        </div>

        {/* Printable A4 Itinerary Sheet */}
        <div id="printable-area" style={{ width: '794px', margin: '30px auto', padding: '40px', backgroundColor: '#ffffff', boxShadow: '0 4px 16px rgba(0,0,0,0.1)', boxSizing: 'border-box', color: '#000000', fontFamily: '"Segoe UI", Roboto, Helvetica, Arial, sans-serif', display: 'block' }}>
          <div className="print-page-border" />
          <table style={{ width: '100%', borderCollapse: 'collapse', border: 'none' }}>
            <thead>
              <tr>
                <td style={{ border: 'none', padding: '0 0 20px 0' }}>
                  {/* Header Brand */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '2.5px solid #d97706', paddingBottom: '12px' }}>
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
                      <img src="/maru_logo.png" alt="Maru Travel" style={{ height: '48px', marginBottom: '4px' }} />
                      <span style={{ fontSize: '0.62rem', letterSpacing: '2px', fontWeight: '800', color: '#d97706', textTransform: 'uppercase', margin: 0 }}>Making Travel an experience</span>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <h2 style={{ fontSize: '1.25rem', fontWeight: '800', color: '#d97706', letterSpacing: '1px', textTransform: 'uppercase', margin: 0 }}>“{tourData.tourName}”</h2>
                    </div>
                  </div>
                </td>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td style={{ border: 'none', padding: 0 }}>
                  {/* Brief Narrative Itinerary Layout */}
                  <div style={{ padding: '0 10px' }}>
                    <div style={{ textAlign: 'center', marginBottom: '24px' }}>
                      <div style={{ fontSize: '1rem', fontWeight: '800', textTransform: 'uppercase', color: '#0F172A', letterSpacing: '1.5px' }}>
                        {Array.from(new Set(tourData.itinerary?.map(d => d.city).filter(Boolean))).join(' - ')}
                      </div>
                      <div style={{ fontSize: '0.85rem', fontWeight: '700', color: '#475569', marginTop: '4px' }}>
                        {String(tourData.itinerary?.length ? tourData.itinerary.length - 1 : 0).padStart(2, '0')} Nights / {String(tourData.itinerary?.length || 0).padStart(2, '0')} Days
                      </div>
                    </div>

                    <div style={{ borderLeft: '3px solid #d97706', paddingLeft: '16px', margin: '20px 0' }}>
                      <span style={{ backgroundColor: '#0B4F6C', color: '#ffffff', padding: '4px 10px', fontWeight: '800', fontSize: '0.75rem', letterSpacing: '1px', textTransform: 'uppercase', borderRadius: '4px' }}>
                        Detailed Itinerary
                      </span>
                    </div>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px', margin: '20px 0' }}>
                      {tourData.itinerary?.map((day, idx) => (
                        <div key={idx} style={{ 
                          pageBreakInside: 'avoid', 
                          breakInside: 'avoid',
                          border: '1px solid #E2E8F0',
                          borderRadius: '8px',
                          padding: '16px',
                          backgroundColor: '#FCFBFA',
                          boxShadow: '0 1px 3px rgba(0,0,0,0.02)'
                        }}>
                          {/* Day Title Block */}
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1.5px solid #E2E8F0', paddingBottom: '10px', marginBottom: '12px' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                              <span style={{ backgroundColor: '#d97706', color: '#ffffff', padding: '3px 8px', borderRadius: '4px', fontSize: '0.8rem', fontWeight: '800' }}>
                                DAY {day.day}
                              </span>
                              <span style={{ fontSize: '0.9rem', fontWeight: '700', color: '#0F172A' }}>
                                {day.dateStr}
                              </span>
                            </div>
                            <span style={{ fontSize: '0.9rem', fontWeight: '800', color: '#0B4F6C', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                              {day.city}
                            </span>
                          </div>

                          {/* Day Activities */}
                          <div style={{ fontSize: '0.88rem', color: '#334155', lineHeight: '1.6', marginBottom: '14px', textAlign: 'justify' }}>
                            {day.activities || 'Leisure / Free time'} 
                          </div>

                          {/* Services Summary Box */}
                          <div style={{ 
                            display: 'grid', 
                            gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', 
                            gap: '12px', 
                            padding: '10px 14px', 
                            backgroundColor: '#F1F5F9', 
                            borderRadius: '6px',
                            fontSize: '0.8rem',
                            color: '#475569'
                          }}>
                            {day.hotelName && (
                              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                <span style={{ fontSize: '1rem' }}>🏨</span>
                                <div>
                                  <strong style={{ color: '#0F172A', display: 'block', fontSize: '0.72rem', textTransform: 'uppercase', opacity: 0.8 }}>Hotel Accommodation</strong>
                                  <span style={{ fontWeight: '600' }}>{day.hotelName}</span>
                                </div>
                              </div>
                            )}
                            {day.mealPlan && (
                              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                <span style={{ fontSize: '1rem' }}>🍽️</span>
                                <div>
                                  <strong style={{ color: '#0F172A', display: 'block', fontSize: '0.72rem', textTransform: 'uppercase', opacity: 0.8 }}>Meal Plan</strong>
                                  <span style={{ fontWeight: '600' }}>{day.mealPlan}</span>
                                </div>
                              </div>
                            )}
                            {(day.transport || day.flightNo || day.trainNo) && (
                              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                <span style={{ fontSize: '1rem' }}>🚗</span>
                                <div>
                                  <strong style={{ color: '#0F172A', display: 'block', fontSize: '0.72rem', textTransform: 'uppercase', opacity: 0.8 }}>Transport</strong>
                                  <span style={{ fontWeight: '600' }}>
                                    {day.flightNo ? `Flight: ${day.flightNo}` : day.trainNo ? `Train: ${day.trainNo}` : day.transport || 'By Surface'}
                                  </span>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>

                    <div style={{ textAlign: 'center', fontWeight: '800', fontSize: '0.95rem', margin: '40px 0 20px 0', letterSpacing: '2px', color: '#94A3B8' }}>
                      --- TOUR ENDS ---
                    </div>
                  </div>
                </td>
              </tr>
            </tbody>
            <tfoot>
              <tr>
                <td style={{ border: 'none', padding: '20px 0 0 0' }}>
                  {/* Structured Formal Footer Company Contact Address block */}
                  <div style={{ borderTop: '2px solid #d97706', paddingTop: '16px', display: 'flex', justifyContent: 'space-between', fontSize: '0.78rem', color: '#334155', fontFamily: 'sans-serif' }}>
                    <div>
                      <h4 style={{ margin: '0 0 4px 0', color: '#000000', fontWeight: '800', fontSize: '0.9rem' }}>Maru Travel</h4>
                      <div style={{ fontSize: '0.62rem', letterSpacing: '1px', fontWeight: '800', color: '#d97706', textTransform: 'uppercase', marginBottom: '8px' }}>
                        INDIA &nbsp;|&nbsp; SOUTH KOREA
                      </div>
                      <strong style={{ fontSize: '0.72rem', color: '#000000' }}>DELHI OFFICE:</strong>
                      <p style={{ margin: '2px 0 0 0', lineHeight: '1.4', fontSize: '0.75rem', color: '#475569' }}>
                        6A, First Floor, Uttam Nagar Main Rd<br/>
                        Near Metro Pillar No. 666<br/>
                        New Delhi - 110059
                      </p>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', textAlign: 'right', gap: '2px', fontSize: '0.75rem', color: '#475569' }}>
                      <span><strong>Mobile phone:</strong> +91-9811430044</span>
                      <span><strong>E Mail:</strong> ranjan@maru.travel</span>
                    </div>
                  </div>
                </td>
              </tr>
            </tfoot>
          </table>

        </div>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      {/* Top Header Bar */}
      <header style={styles.header}>
        <div style={styles.headerLeft}>
          <img src="/maru_logo.png" alt="Maru Travel" style={styles.headerLogo} />
          <div>
            <h1 style={styles.headerTitle}>Driver Panel</h1>
            <span style={styles.headerSubtitle}>{tourData.driverName}</span>
          </div>
        </div>
        <div style={styles.headerRight}>
          <div style={styles.gpsBadge}>
            <span style={{
              width: '8px', height: '8px', borderRadius: '50%',
              backgroundColor: isSimulating ? '#22c55e' : '#94a3b8',
              animation: isSimulating ? 'mapPulse 1.5s infinite' : 'none'
            }} />
            <span style={{ fontSize: '0.65rem', fontWeight: '700' }}>
              {isSimulating ? 'LIVE' : 'OFF'}
            </span>
          </div>
          <button onClick={() => setShowPrintPreview(true)} style={{ ...styles.logoutBtn, backgroundColor: '#facc15', color: '#000', marginRight: '6px' }}>
            <Printer size={16} />
          </button>
          <button onClick={onLogout} style={styles.logoutBtn}>
            <X size={16} />
          </button>
        </div>
      </header>

      {/* Main Scrollable Content */}
      <main style={styles.mainContent}>

        {/* NEXT UP Card — Green accent card */}
        <div style={styles.nextUpCard}>
          <div style={styles.nextUpHeader}>
            <span style={styles.nextUpBadge}>
              <Clock size={12} /> NEXT UP • {nextActivity.time || '09:00 AM'}
            </span>
          </div>
          <h2 style={styles.nextUpTitle}>{nextActivity.title || currentDay.city + ' Visit'}</h2>
          <p style={styles.nextUpDesc}>
            {currentDay.activities?.substring(0, 120)}...
          </p>
          <div style={styles.nextUpActions}>
            <a
              href={currentDay.hotelMapLink || `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(currentDay.city + ', India')}`}
              target="_blank"
              rel="noreferrer"
              style={styles.nextUpNavBtn}
            >
              <Navigation size={14} /> Navigate to Gate
            </a>
            <a href={`tel:${tourData.guideMobile}`} style={styles.nextUpCallBtn}>
              <Phone size={14} /> Call Guide
            </a>
          </div>
        </div>

        {/* Vehicle Status Card */}
        <div style={styles.vehicleCard}>
          <h3 style={styles.sectionTitle}>
            <Car size={16} color="#1a8a7d" /> VEHICLE STATUS
          </h3>
          <div style={styles.vehicleGrid}>
            <div style={styles.vehicleRow}>
              <span style={styles.vehicleLabel}>Vehicle</span>
              <span style={styles.vehicleValue}>{tourData.vehicleType || 'Toyota Innova Crysta'}</span>
            </div>
            <div style={styles.vehicleRow}>
              <span style={styles.vehicleLabel}>Reg No.</span>
              <span style={styles.vehicleValue}>{tourData.vehicleNo || 'DL 1Z 4567'}</span>
            </div>
            <div style={styles.vehicleRow}>
              <span style={styles.vehicleLabel}>Water Stock</span>
              <span style={{ ...styles.vehicleValue, color: '#22c55e', fontWeight: '700' }}>
                Adequate ({tourData.pax * 3} ltrs)
              </span>
            </div>
          </div>
          <p style={styles.vehicleNote}>
            ⚠️ View-only mode. Contact operator for changes.
          </p>
        </div>

        {/* Tour Info Summary */}
        <div style={styles.tourInfoCard}>
          <div style={styles.tourInfoRow}>
            <div style={styles.tourInfoItem}>
              <span style={styles.tourInfoLabel}>Guest</span>
              <span style={styles.tourInfoValue}>{tourData.clientName}</span>
            </div>
            <div style={styles.tourInfoItem}>
              <span style={styles.tourInfoLabel}>Tour Code</span>
              <span style={styles.tourInfoValue}>{tourCode}</span>
            </div>
          </div>
          <div style={styles.tourInfoRow}>
            <div style={styles.tourInfoItem}>
              <span style={styles.tourInfoLabel}>Guide</span>
              <span style={styles.tourInfoValue}>{tourData.guideName}</span>
            </div>
            <div style={styles.tourInfoItem}>
              <span style={styles.tourInfoLabel}>Pax</span>
              <span style={styles.tourInfoValue}>{tourData.pax} Guests</span>
            </div>
          </div>
        </div>

        {/* Today's Itinerary — Timeline style */}
        <div style={styles.todaySection}>
          <div style={styles.todaySectionHeader}>
            <h3 style={styles.sectionTitle}>
              <Calendar size={16} color="#1a8a7d" /> Today's Itinerary
            </h3>
            <span style={styles.dayBadge}>Day {currentDay.day} · {currentDay.city}</span>
          </div>

          <div style={styles.timelineContainer}>
            {currentDay.activitiesList?.map((act, idx) => (
              <div key={idx} style={styles.timelineItem}>
                <div style={styles.timelineDotCol}>
                  <div style={{
                    ...styles.timelineDot,
                    backgroundColor: idx === 0 ? '#1a8a7d' : '#cbd5e1'
                  }} />
                  {idx < (currentDay.activitiesList.length - 1) && (
                    <div style={styles.timelineLine} />
                  )}
                </div>
                <div style={styles.timelineContent}>
                  <div style={styles.timelineCard}>
                    <span style={styles.timelineTime}>{act.time}</span>
                    <h4 style={styles.timelineTitle}>{act.title}</h4>
                  </div>
                </div>
              </div>
            ))}

            {/* Dinner / Meal entry */}
            {currentDay.mealPlan && (
              <div style={styles.timelineItem}>
                <div style={styles.timelineDotCol}>
                  <div style={{ ...styles.timelineDot, backgroundColor: '#f59e0b' }} />
                </div>
                <div style={styles.timelineContent}>
                  <div style={styles.timelineCard}>
                    <span style={styles.timelineTime}>Evening</span>
                    <h4 style={styles.timelineTitle}>🍽️ {currentDay.mealPlan}</h4>
                    <p style={styles.timelineDesc}>At {currentDay.hotelName}</p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Open in Google Maps */}
          {currentDay.hotelMapLink && (
            <a href={currentDay.hotelMapLink} target="_blank" rel="noreferrer" style={styles.googleMapsBtn}>
              <MapPin size={14} /> Open in Google Maps
            </a>
          )}
        </div>

        {/* Full Tour Days — Scrollable list */}
        <div style={styles.fullTourSection}>
          <h3 style={styles.sectionTitle}>
            <Compass size={16} color="#1a8a7d" /> Full Tour Days ({completedDays}/{totalDays} completed)
          </h3>

          <div style={styles.daysListContainer}>
            {tourData.itinerary?.map((day, idx) => {
              const isToday = idx === realActiveDayIdx;
              const isPast = idx < realActiveDayIdx;
              const isArrived = day.arrived;

              return (
                <div
                  key={idx}
                  ref={isToday ? activeDayRef : null}
                  style={{
                    ...styles.dayCard,
                    borderLeft: isToday ? '4px solid #1a8a7d' : isArrived ? '4px solid #22c55e' : '4px solid #e2e8f0',
                    backgroundColor: isToday ? '#f0fdf4' : 'white',
                    opacity: !isToday && !isPast && !isArrived ? 0.7 : 1
                  }}
                >
                  <div style={styles.dayCardHeader}>
                    <div>
                      <span style={{
                        ...styles.dayTag,
                        color: isToday ? '#1a8a7d' : '#64748b'
                      }}>
                        DAY {day.day} · {day.dateStr}
                      </span>
                      <h4 style={styles.dayCity}>{day.city}</h4>
                      {day.hotelName && (
                        <span style={styles.dayHotel}>🏨 {day.hotelName}</span>
                      )}
                      {day.flightNo && (
                        <span style={{...styles.dayHotel, marginTop: '4px'}}>✈️ {day.flightNo}</span>
                      )}
                      {day.trainNo && (
                        <span style={{...styles.dayHotel, marginTop: '4px'}}>🚆 {day.trainNo}</span>
                      )}
                      {day.localRestaurant && (
                        <span style={{...styles.dayHotel, marginTop: '4px', color: '#d97706'}}>🍽️ {day.localRestaurant} ({day.restaurantMealType})</span>
                      )}
                    </div>

                    <div style={styles.dayCardRight}>
                      {isArrived ? (
                        <div style={styles.arrivedBadge}>
                          <CheckCircle2 size={14} />
                          <div>
                            <span style={styles.arrivedText}>Arrived</span>
                            {day.arrivedAt && (
                              <span style={styles.arrivedTime}>{day.arrivedAt}</span>
                            )}
                          </div>
                        </div>
                      ) : (
                        <button
                          onClick={() => handleMarkArrived(idx)}
                          style={{
                            ...styles.markArrivedBtn,
                            backgroundColor: isToday ? '#1a8a7d' : '#94a3b8'
                          }}
                        >
                          <MapPin size={12} /> Mark Arrived
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Brief activity summary */}
                  <p style={styles.dayActivities}>
                    {day.activities?.substring(0, 100)}{day.activities?.length > 100 ? '...' : ''}
                  </p>

                  {/* Navigate to hotel */}
                  {day.hotelMapLink && (
                    <a href={day.hotelMapLink} target="_blank" rel="noreferrer" style={styles.dayMapLink}>
                      <Navigation size={12} /> Navigate to Hotel
                    </a>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* GPS Broadcast Control */}
        <div style={styles.gpsCard}>
          <h3 style={styles.sectionTitle}>
            <Compass size={16} color="#1a8a7d" /> GPS Broadcast
          </h3>
          <p style={styles.gpsStatus}>
            {isSimulating
              ? `📡 Broadcasting: ${coords.lat.toFixed(4)}, ${coords.lng.toFixed(4)}`
              : '⚪ GPS broadcast is idle. Start to share your live location with guests.'}
          </p>
          <button onClick={toggleSimulation} style={{
            ...styles.gpsToggleBtn,
            backgroundColor: isSimulating ? '#ef4444' : '#1a8a7d'
          }}>
            {isSimulating ? (
              <><Square size={14} /> Stop Broadcasting</>
            ) : (
              <><Play size={14} /> Start Live Broadcast</>
            )}
          </button>
        </div>

        {/* Emergency Report Button */}
        <button
          onClick={() => setShowReportModal(true)}
          style={styles.emergencyBtn}
        >
          <AlertTriangle size={16} /> Report Emergency / Delay
        </button>

        {/* Quick Contact Row */}
        <div style={styles.contactRow}>
          <a href={`tel:${tourData.guideMobile}`} style={styles.contactBtn}>
            <Phone size={14} /> Call Guide
          </a>
          <a href="tel:+919999999999" style={{ ...styles.contactBtn, backgroundColor: '#0f172a', color: '#fff' }}>
            <Shield size={14} /> Call HQ
          </a>
        </div>

      </main>

      {/* Emergency Report Modal */}
      {showReportModal && (
        <div style={styles.modalOverlay} onClick={() => setShowReportModal(false)}>
          <div style={styles.modalSheet} onClick={(e) => e.stopPropagation()}>
            <div style={styles.modalHeader}>
              <h3 style={styles.modalTitle}>
                <AlertOctagon size={20} color="#ef4444" /> Report Issue
              </h3>
              <button onClick={() => setShowReportModal(false)} style={styles.modalCloseBtn}>
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleReportProblem} style={styles.modalForm}>
              <div>
                <label style={styles.formLabel}>Issue Category</label>
                <select
                  style={styles.formSelect}
                  value={problemCategory}
                  onChange={(e) => setProblemCategory(e.target.value)}
                >
                  <option value="Traffic">🚦 Heavy Traffic / Delay</option>
                  <option value="Breakdown">🔧 Vehicle Breakdown</option>
                  <option value="AC Issue">❄️ AC / Comfort Issue</option>
                  <option value="Medical Alert">🏥 Medical Emergency</option>
                  <option value="Road Block">🚧 Road Block / Diversion</option>
                  <option value="Accident">⚠️ Accident / Safety</option>
                </select>
              </div>

              <div>
                <label style={styles.formLabel}>Additional Notes (Optional)</label>
                <textarea
                  style={styles.formTextarea}
                  placeholder="Describe the issue briefly..."
                  value={problemNote}
                  onChange={(e) => setProblemNote(e.target.value)}
                  rows={3}
                />
              </div>

              {problemSuccess && (
                <p style={{ color: '#22c55e', fontWeight: '700', fontSize: '0.85rem' }}>
                  ✅ {problemSuccess}
                </p>
              )}

              <button type="submit" disabled={isProblemSending} style={styles.submitAlertBtn}>
                {isProblemSending ? 'Sending...' : '🚨 Send Alert to Headquarters'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

const styles = {
  container: {
    height: '100vh',
    overflowY: 'auto',
    backgroundColor: '#f8fafc',
    display: 'flex',
    flexDirection: 'column',
    fontFamily: "'Inter', 'Outfit', sans-serif",
  },
  loaderWrap: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: '100vh',
    gap: '12px',
    backgroundColor: '#f8fafc'
  },
  spinner: {
    width: '32px',
    height: '32px',
    border: '3px solid #e2e8f0',
    borderTopColor: '#1a8a7d',
    borderRadius: '50%',
    animation: 'spin 1s linear infinite'
  },

  // Header
  header: {
    backgroundColor: '#ffffff',
    borderBottom: '1px solid #e2e8f0',
    padding: '12px 16px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    position: 'sticky',
    top: 0,
    zIndex: 100,
    boxShadow: '0 1px 3px rgba(0,0,0,0.06)'
  },
  headerLeft: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px'
  },
  headerLogo: {
    height: '32px',
    width: 'auto'
  },
  headerTitle: {
    fontSize: '1rem',
    fontWeight: '800',
    color: '#0f172a',
    margin: 0,
    lineHeight: 1.2
  },
  headerSubtitle: {
    fontSize: '0.72rem',
    color: '#64748b',
    fontWeight: '600'
  },
  headerRight: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px'
  },
  gpsBadge: {
    display: 'flex',
    alignItems: 'center',
    gap: '4px',
    backgroundColor: '#f1f5f9',
    padding: '4px 8px',
    borderRadius: '20px',
    fontSize: '0.7rem',
    fontWeight: '700',
    color: '#475569'
  },
  logoutBtn: {
    width: '32px',
    height: '32px',
    borderRadius: '50%',
    border: '1px solid #e2e8f0',
    backgroundColor: '#fff',
    color: '#64748b',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    cursor: 'pointer'
  },

  // Main content
  mainContent: {
    flex: 1,
    padding: '16px',
    display: 'flex',
    flexDirection: 'column',
    gap: '16px',
    paddingBottom: '40px',
    maxWidth: '600px',
    margin: '0 auto',
    width: '100%'
  },

  // NEXT UP Card
  nextUpCard: {
    background: 'linear-gradient(135deg, #065f46, #047857)',
    borderRadius: '16px',
    padding: '20px',
    color: '#ffffff',
    boxShadow: '0 4px 16px rgba(4, 120, 87, 0.3)'
  },
  nextUpHeader: {
    marginBottom: '8px'
  },
  nextUpBadge: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '6px',
    backgroundColor: 'rgba(255,255,255,0.2)',
    padding: '4px 10px',
    borderRadius: '20px',
    fontSize: '0.7rem',
    fontWeight: '700',
    letterSpacing: '0.5px'
  },
  nextUpTitle: {
    fontSize: '1.3rem',
    fontWeight: '800',
    margin: '8px 0 6px 0',
    lineHeight: 1.2
  },
  nextUpDesc: {
    fontSize: '0.82rem',
    opacity: 0.9,
    lineHeight: 1.4,
    marginBottom: '14px'
  },
  nextUpActions: {
    display: 'flex',
    gap: '8px'
  },
  nextUpNavBtn: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '6px',
    backgroundColor: 'rgba(255,255,255,0.2)',
    color: '#ffffff',
    padding: '8px 14px',
    borderRadius: '10px',
    fontSize: '0.78rem',
    fontWeight: '700',
    textDecoration: 'none',
    border: '1px solid rgba(255,255,255,0.3)',
    cursor: 'pointer',
    transition: 'all 0.2s ease'
  },
  nextUpCallBtn: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '6px',
    backgroundColor: '#ffffff',
    color: '#065f46',
    padding: '8px 14px',
    borderRadius: '10px',
    fontSize: '0.78rem',
    fontWeight: '700',
    textDecoration: 'none',
    cursor: 'pointer'
  },

  // Vehicle Card
  vehicleCard: {
    backgroundColor: '#ffffff',
    borderRadius: '14px',
    padding: '16px',
    border: '1px solid #e2e8f0',
    boxShadow: '0 1px 4px rgba(0,0,0,0.04)'
  },
  sectionTitle: {
    fontSize: '0.78rem',
    fontWeight: '800',
    color: '#0f172a',
    letterSpacing: '0.5px',
    textTransform: 'uppercase',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    margin: '0 0 12px 0'
  },
  vehicleGrid: {
    display: 'flex',
    flexDirection: 'column',
    gap: '8px'
  },
  vehicleRow: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '6px 0',
    borderBottom: '1px solid #f1f5f9'
  },
  vehicleLabel: {
    fontSize: '0.82rem',
    color: '#64748b',
    fontWeight: '600'
  },
  vehicleValue: {
    fontSize: '0.82rem',
    color: '#0f172a',
    fontWeight: '700'
  },
  vehicleNote: {
    fontSize: '0.72rem',
    color: '#94a3b8',
    marginTop: '10px',
    fontStyle: 'italic'
  },

  // Tour Info Card
  tourInfoCard: {
    backgroundColor: '#ffffff',
    borderRadius: '14px',
    padding: '16px',
    border: '1px solid #e2e8f0',
    display: 'flex',
    flexDirection: 'column',
    gap: '10px'
  },
  tourInfoRow: {
    display: 'flex',
    gap: '12px'
  },
  tourInfoItem: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    gap: '2px'
  },
  tourInfoLabel: {
    fontSize: '0.68rem',
    color: '#94a3b8',
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: '0.5px'
  },
  tourInfoValue: {
    fontSize: '0.85rem',
    color: '#0f172a',
    fontWeight: '700'
  },

  // Today's Itinerary
  todaySection: {
    backgroundColor: '#ffffff',
    borderRadius: '14px',
    padding: '16px',
    border: '1px solid #e2e8f0'
  },
  todaySectionHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: '4px'
  },
  dayBadge: {
    fontSize: '0.72rem',
    fontWeight: '700',
    color: '#1a8a7d',
    backgroundColor: '#f0fdf4',
    padding: '4px 10px',
    borderRadius: '20px',
    border: '1px solid #bbf7d0'
  },
  timelineContainer: {
    display: 'flex',
    flexDirection: 'column',
    gap: '0px'
  },
  timelineItem: {
    display: 'flex',
    gap: '12px',
    minHeight: '52px'
  },
  timelineDotCol: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    width: '20px',
    paddingTop: '6px'
  },
  timelineDot: {
    width: '10px',
    height: '10px',
    borderRadius: '50%',
    flexShrink: 0
  },
  timelineLine: {
    width: '2px',
    flex: 1,
    backgroundColor: '#e2e8f0',
    marginTop: '4px'
  },
  timelineContent: {
    flex: 1,
    paddingBottom: '12px'
  },
  timelineCard: {
    backgroundColor: '#f8fafc',
    borderRadius: '10px',
    padding: '10px 12px',
    border: '1px solid #f1f5f9'
  },
  timelineTime: {
    fontSize: '0.72rem',
    fontWeight: '800',
    color: '#1a8a7d',
    letterSpacing: '0.3px'
  },
  timelineTitle: {
    fontSize: '0.88rem',
    fontWeight: '700',
    color: '#0f172a',
    margin: '2px 0 0 0'
  },
  timelineDesc: {
    fontSize: '0.75rem',
    color: '#64748b',
    marginTop: '2px'
  },
  googleMapsBtn: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '6px',
    backgroundColor: '#f0fdf4',
    color: '#1a8a7d',
    border: '1px solid #bbf7d0',
    padding: '10px',
    borderRadius: '10px',
    fontSize: '0.82rem',
    fontWeight: '700',
    textDecoration: 'none',
    marginTop: '12px',
    cursor: 'pointer'
  },

  // Full Tour Days
  fullTourSection: {
    display: 'flex',
    flexDirection: 'column',
    gap: '12px'
  },
  daysListContainer: {
    display: 'flex',
    flexDirection: 'column',
    gap: '10px'
  },
  dayCard: {
    backgroundColor: '#ffffff',
    borderRadius: '12px',
    padding: '14px 16px',
    border: '1px solid #e2e8f0',
    transition: 'all 0.2s ease'
  },
  dayCardHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: '8px'
  },
  dayTag: {
    fontSize: '0.68rem',
    fontWeight: '800',
    letterSpacing: '0.5px',
    textTransform: 'uppercase'
  },
  dayCity: {
    fontSize: '1.05rem',
    fontWeight: '800',
    color: '#0f172a',
    margin: '2px 0 0 0'
  },
  dayHotel: {
    fontSize: '0.72rem',
    color: '#64748b',
    fontWeight: '600'
  },
  dayCardRight: {
    display: 'flex',
    alignItems: 'flex-start'
  },
  arrivedBadge: {
    display: 'flex',
    alignItems: 'center',
    gap: '6px',
    color: '#22c55e',
    fontSize: '0.78rem',
    fontWeight: '700'
  },
  arrivedText: {
    display: 'block',
    fontWeight: '700'
  },
  arrivedTime: {
    display: 'block',
    fontSize: '0.65rem',
    color: '#94a3b8',
    fontWeight: '600'
  },
  markArrivedBtn: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '4px',
    color: '#ffffff',
    border: 'none',
    padding: '6px 12px',
    borderRadius: '20px',
    fontSize: '0.72rem',
    fontWeight: '700',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    whiteSpace: 'nowrap'
  },
  dayActivities: {
    fontSize: '0.78rem',
    color: '#64748b',
    lineHeight: 1.4,
    margin: 0
  },
  dayMapLink: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '4px',
    color: '#1a8a7d',
    fontSize: '0.75rem',
    fontWeight: '700',
    textDecoration: 'none',
    marginTop: '8px'
  },

  // GPS Card
  gpsCard: {
    backgroundColor: '#ffffff',
    borderRadius: '14px',
    padding: '16px',
    border: '1px solid #e2e8f0'
  },
  gpsStatus: {
    fontSize: '0.82rem',
    color: '#64748b',
    marginBottom: '12px',
    lineHeight: 1.4
  },
  gpsToggleBtn: {
    width: '100%',
    color: '#ffffff',
    border: 'none',
    padding: '12px',
    borderRadius: '10px',
    fontSize: '0.85rem',
    fontWeight: '700',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    transition: 'all 0.2s ease'
  },

  // Emergency & Contact
  emergencyBtn: {
    width: '100%',
    backgroundColor: '#fef2f2',
    color: '#ef4444',
    border: '1px solid #fecaca',
    padding: '12px',
    borderRadius: '12px',
    fontSize: '0.85rem',
    fontWeight: '700',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px'
  },
  contactRow: {
    display: 'flex',
    gap: '10px'
  },
  contactBtn: {
    flex: 1,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '6px',
    backgroundColor: '#1a8a7d',
    color: '#ffffff',
    padding: '12px',
    borderRadius: '12px',
    fontSize: '0.82rem',
    fontWeight: '700',
    textDecoration: 'none',
    cursor: 'pointer'
  },

  // Modal
  modalOverlay: {
    position: 'fixed',
    top: 0, left: 0, right: 0, bottom: 0,
    backgroundColor: 'rgba(15, 23, 42, 0.5)',
    backdropFilter: 'blur(4px)',
    display: 'flex',
    alignItems: 'flex-end',
    justifyContent: 'center',
    zIndex: 9999
  },
  modalSheet: {
    backgroundColor: '#ffffff',
    borderRadius: '20px 20px 0 0',
    width: '100%',
    maxWidth: '500px',
    padding: '24px',
    maxHeight: '80vh',
    overflowY: 'auto',
    animation: 'slideUp 0.3s ease'
  },
  modalHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '20px'
  },
  modalTitle: {
    fontSize: '1.1rem',
    fontWeight: '800',
    color: '#0f172a',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    margin: 0
  },
  modalCloseBtn: {
    width: '32px',
    height: '32px',
    borderRadius: '50%',
    border: '1px solid #e2e8f0',
    backgroundColor: '#fff',
    color: '#64748b',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    cursor: 'pointer'
  },
  modalForm: {
    display: 'flex',
    flexDirection: 'column',
    gap: '16px'
  },
  formLabel: {
    fontSize: '0.75rem',
    fontWeight: '700',
    color: '#64748b',
    textTransform: 'uppercase',
    letterSpacing: '0.5px',
    marginBottom: '6px',
    display: 'block'
  },
  formSelect: {
    width: '100%',
    padding: '10px 12px',
    borderRadius: '10px',
    border: '1px solid #e2e8f0',
    fontSize: '0.88rem',
    backgroundColor: '#f8fafc',
    color: '#0f172a',
    fontWeight: '600'
  },
  formTextarea: {
    width: '100%',
    padding: '10px 12px',
    borderRadius: '10px',
    border: '1px solid #e2e8f0',
    fontSize: '0.85rem',
    backgroundColor: '#f8fafc',
    color: '#0f172a',
    fontFamily: "'Inter', sans-serif",
    resize: 'vertical'
  },
  submitAlertBtn: {
    width: '100%',
    backgroundColor: '#ef4444',
    color: '#ffffff',
    border: 'none',
    padding: '14px',
    borderRadius: '12px',
    fontSize: '0.9rem',
    fontWeight: '800',
    cursor: 'pointer'
  }
};
